<?php
	//$wsdl = 'dev';
	$wsdl = 'prod';
	
	if ($wsdl == 'dev') {
	
		// Dev
		$service = new SoapClient(	
			"https://dev.cascade.emory.edu/ws/services/AssetOperationService?wsdl",
			array('trace' => 1,
			'location' => 'https://dev.cascade.emory.edu/ws/services/AssetOperationService'));
					
	} elseif ($wsdl == 'prod') {
	
		// Prod
		$service = new SoapClient(	
			"http://cascade.emory.edu/ws/services/AssetOperationService?wsdl",
			array('trace' => 1,
			'location' => 'http://cascade.emory.edu/ws/services/AssetOperationService'));

	} else {
		// Error
	}
	
	$auth = array('username' => 'YourID', 'password' => 'YourPassword');
?>