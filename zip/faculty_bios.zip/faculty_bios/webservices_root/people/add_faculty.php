<?php
	session_start();
?>

<?php 
	ini_set('display_errors', 1);
	ini_set('log_errors', 1);
	error_reporting(E_ERROR | E_PARSE);
	set_time_limit(0);
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
	<title>Add Faculty Pages</title>

    <link rel="stylesheet" type="text/css" href="../includes/style.css" />

</head>

<body>

<?php 
	include("../includes/headermenu.php");
	include '../includes/service.php';
	include '../includes/functions.php';
	
	
	echo '<h2>Add Faculty Pages</h2><hr />';
		
	if ($_REQUEST['submit']) {
		if ($_FILES['facultyfile']) {
			$start_webservices = true;
		} else {
			$start_webservices = false;
			$missing = true;
		}
	} // End if ($_REQUEST['submit']) 
	
	if ($start_webservices == true) {	
	
		// Process the Faculty File
		$faculty_file = $_FILES['facultyfile']['name'];
		
		chmod($_FILES['facultyfile']['tmp_name'],777);
		
		if(move_uploaded_file($_FILES['facultyfile']['tmp_name'], $faculty_file)) {
					
			$handle = fopen( $faculty_file, "r");
			
			while (($data = fgetcsv($handle, 1000, ",")) !== FALSE) {
				$totalCount++;
			
				// Set Columns
				if ($data[0] == 'PRSN_I (Padded to 8 CHARS, EmplID)') {
					$num = count($data);             
					for ($c=0; $c < $num; $c++) {
						switch ($data[$c]) {
							case "PRSN_I_PBLC (Public Key ID)":
								$public_key_id = $c;
								break;
							case "First Name":
								$first_name =$c;
								break;
							case "Middle Name":
								$middle_name =$c;
								break;
							case "Last Name":
								$last_name =$c;
								break;
							case "Suffix":
								$suffix =$c;
								break;
							case "Official Job Title":
								$official_job_title =$c;
								break;
							case "Primary Department":
								$primary_department =$c;
								break;
							case "Email Address":
								$email_address =$c;
								break;
							case "Phone Number":
								$phone_number =$c;
								break;
							case "Fax Number":
								$fax_number =$c;
								break;
							case "Mail Stop Number":
								$mail_stop_number =$c;
								break;
							case "Mail Stop Name":
								$mail_stop_name =$c;
								break;
							case "Address":
								$address =$c;
								break;
						}
					}
					
				} else {         
					
					// Set Variables From Spreadsheet
						if ($data[$public_key_id]) { $data_public_key_id = $data[$public_key_id]; } else { $data_public_key_id = ""; }
						if ($data[$first_name]) { $data_first_name = $data[$first_name]; } else { $data_first_name = ""; }
						if ($data[$middle_name]) { $data_middle_name = $data[$middle_name]; } else { $data_middle_name = ""; }
						if ($data[$last_name]) { $data_last_name = $data[$last_name]; } else { $data_last_name = ""; }
						if ($data[$suffix]) { $data_suffix = $data[$suffix]; } else { $data_suffix = ""; }
						if ($data[$official_job_title]) { $data_official_job_title = $data[$official_job_title]; } else { $data_official_job_title = ""; }
						if ($data[$primary_department]) { $data_primary_department = $data[$primary_department]; } else { $data_primary_department = ""; }
						if ($data[$email_address]) { $data_email_address = $data[$email_address]; } else { $data_email_address = ""; }
						if ($data[$phone_number]) { $data_phone_number = $data[$phone_number]; } else { $data_phone_number = ""; }
						if ($data[$fax_number]) { $data_fax_number = $data[$fax_number]; } else { $data_fax_number = ""; }
						if ($data[$mail_stop_number]) { $data_mail_stop_number = $data[$mail_stop_number]; } else { $data_mail_stop_number = ""; }
						if ($data[$mail_stop_name]) { $data_mail_stop_name = $data[$mail_stop_name]; } else { $data_mail_stop_name = ""; }
						if ($data[$address]) { $data_address = $data[$address]; } else { $data_address = ""; }
				
						
					// Set Combination Variables
						$data_system_name = $data_last_name .'_'. $data_first_name .'_'. $data_public_key_id ;
							// Removes Spaces 
							$data_system_name = str_replace(" ", "_", $data_system_name);
							// Removes periods
							$data_system_name = str_replace(".", "", $data_system_name);
							// Removes apostrophes
							$data_system_name = str_replace("'", "", $data_system_name);
							
						$data_parent_folder = "about/people/faculty";
						$data_expiration_folder = "about/people/faculty";
						$data_metadata_set = "faculty";
						$data_perosn_category = "Faculty";
						$data_faculty_rank = "Instructor";
						$data_institution_name1 = "UndergraduateEmoryCollege";
						$data_institution_name2 = "GraduateArtsSciences";
						$data_display_name = $data_first_name . ' ' . $data_last_name;
						
						// Address Variables
						$data_address_line = 'Emory University';
						$data_municipality = 'Atlanta';
						$data_region = 'GA';
						$data_postal_code = '30322';
						$data_country_code = 'USA';
						
						// Telephone Variables
						if ($data_phone_number == '') {
							$data_telephone_international_country_code = '';
							$data_telephone_national_number = '';
							$data_telephone_area_city_code = '';
							$data_telephone_subscriber_number = '';
							$data_telephone_extension = '';
						} else {
							list($data_telephone_area_city_code, $data_telephone_subscriber_number, $data_telephone_extension) = 
							split('[/.-]', $data_phone_number);
							$data_telephone_international_country_code = '00';
							$data_telephone_national_number = '1';
						}
						
						// Fax Variables
						if ($data_fax_number == '') {
							$data_fax_international_country_code = '';
							$data_fax_national_number = '';
							$data_fax_area_city_code = '';
							$data_fax_subscriber_number = '';
							$data_fax_extension = '';
						} else {
							list($data_fax_area_city_code, $data_fax_subscriber_number, $data_fax_extension) = split('[/.-]', $data_fax_number);
							$data_fax_international_country_code = '00';
							$data_fax_national_number = '1';
						}
						
						// Building And Room Variable
						if ($data_address == '') {
							$data_building_room = $data_mail_stop_name;
						} else {
							$data_building_room = $data_address;
						}
					
						// Set Department Asset
						include ('../includes/people_switch.php');	
										
					// Add Course Data
						// Check to see if the person already exists
							$path_to_person = $data_parent_folder . '/' . $data_system_name;
						
							$find_path = array('path' => $path_to_person, 'siteName' => 'College');
							$find_id = array('path' => $find_path, 'type' => 'page');
		
							$find_params = array( 'authentication' => $auth, 'identifier' => $find_id );
			
							// Read
							$find_read = $service->read($find_params);
							
							if ($find_read->readReturn->success != 'true') {	
								// Person does not exist; Add the person
								$addedCount++;
								echo '<font color="#FF0000">Add ' . $data_system_name . '.</font><br/>';
								include ('add_people.php');			
							} else {
								// Person exists; do nothing.
								echo $data_system_name . ' exists.<br/>';
							}	
								   
					$listing = "";
				
					if ($data[$public_key_id]) {
						$listing .= "public_key_id = " . $data[$public_key_id] . "<br/> ";
					}
					
					if ($data[$first_name]) {
						$listing .= "first_name = " . $data[$first_name] . "<br/> ";
					}
					
					if ($data[$middle_name]) {
						$listing .= "middle_name = " . $data[$middle_name] . "<br/> ";
					}
					
					if ($data[$last_name]) {
						$listing .= "last_name = " . $data[$last_name] . "<br/> ";
					}
					
					if ($data[$suffix]) {
						$listing .= "suffix = " . $data[$suffix] . "<br/> ";
					}
					
					if ($data[$official_job_title]) {
						$listing .= "official_job_title = " . $data[$official_job_title] . "<br/> ";
					}
					
					if ($data[$primary_department]) {
						$listing .= "primary_department = " . $data[$primary_department] . "<br/> ";
					}
		
					$listing .= "primary_department_path = " . $data_primary_department_path . "<br/> ";
					
					if ($data[$email_address]) {
						$listing .= "email_address = " . $data[$email_address] . "<br/> ";
					}
					
					if ($data[$phone_number]) {
						$listing .= "phone_number = " . $data[$phone_number] . "<br/> ";
					}
					
					if ($data[$fax_number]) {
						$listing .= "fax_number = " . $data[$fax_number] . "<br/> ";
					}
					
					if ($data[$mail_stop_number]) {
						$listing .= "mail_stop_number = " . $data[$mail_stop_number] . "<br/> ";
					}
					
					if ($data[$mail_stop_name]) {
						$listing .= "mail_stop_name = " . $data[$mail_stop_name] . "<br/> ";
					}
					
					if ($data[$address]) {
						$listing .= "address = " . $data[$address] . "<br/> ";
					}
					$listing .= "<br /><br />";
				} // End if ($data[0]
			} // End while (($data
			echo '<hr width="300px" align="left">';
			fclose($handle);
			if ($totalCount) { $totalCount -= 1; } else {$totalCount = 'None';}
			if ($addedCount) { } else {$addedCount = 'None';}
			if ($failedCount) { } else {$failedCount = 'None';}
			echo 'Total = ' . $totalCount . '<br>';
			echo 'Added = ' . $addedCount . '<br>';
			echo 'Failed = ' . $failedCount . '<br>';
							
		} else {
			echo "<h1>There is a problem with the file you uploaded.</h1>";
		} // End if(move_uploaded_file
					
	} else {
?>
        
		<form enctype="multipart/form-data" action="<?php echo $PHP_SELF;?>" method="post" name="create_edit" target="_self">
			<div class="information">
<?php
					if ($missing) {
?>				
						<p style="color:red;">You must fill out all fields below.</p>
<?php
					}
?>
                
                <p>
                	<input type="hidden" name="MAX_FILE_SIZE" value="1000000000000000" />
					Choose the <strong>faculty</strong> file: <input name="facultyfile" type="file" />
                </p>
                
                <p>
                    <input name="submit" type="submit" value="Start Web Services" />
                </p>
            </div>
		</form>
<?php
	} // End if ($start_webservices == true)
?>
</body>
</html>