<?php	
	
	$log = '';
	
	// Set Page Asset Information
	$asset = array( 
		'page' => array (
			'shouldBePublished' => true,
			'shouldBeIndexed' => true,
			'contentTypePath' => 'faculty',
			'parentFolderPath' => $data_parent_folder,
			'metadataSetPath' => $data_metadata_set,
			'expirationFolderPath' => $data_expiration_folder,
			'name' => $data_system_name,
			'siteName' => 'College',
			'metadata' => array(
				'author' => 'Web Services',
				'displayName' => $data_display_name,
				'title' => $data_display_name
			),
			
			'structuredData' => array (
				'definitionPath' => 'person',
				'structuredDataNodes' => array (													
					'structuredDataNode' => array (
						
						// Employee ID
						array (
							'type' => 'text',
							'identifier' => 'EmployeeId',
							'text' => $data_public_key_id 
						),
						
						// Name Group
						array (
							'type' => 'group',
							'identifier' => 'PersonName',
							'structuredDataNodes' => array (										
								'structuredDataNode' => array (
									// Last Name
									array (
										'type' => 'text',
										'identifier' => 'FamilyName',
										'text' => $data_last_name
									),
							
									// First Name
									array (
										'type' => 'text',
										'identifier' => 'GivenName',
										'text' => $data_first_name 
									),
									
									// Middle Name
									array (
										'type' => 'text',
										'identifier' => 'MiddleName',
										'text' => $data_middle_name
									),
									
									// Suffix
									array (
										'type' => 'text',
										'identifier' => 'Affix',
										'text' => $data_suffix
									)
								)								
							) 
						), //End Name Group
						
						
						// PositionInfo Group	
						array (
							'type' => 'group',
							'identifier' => 'PositionInfo',
							'structuredDataNodes' => array (										
								'structuredDataNode' => array (
									// Institution(s)
									array (
										'type' => 'text',
										'identifier' => 'InstitutionName',
										'text' => $data_institution_name1
									),
									// Institution(s)
									array (
										'type' => 'text',
										'identifier' => 'InstitutionName',
										'text' => $data_institution_name2
									),
									// Title
									array (
										'type' => 'text',
										'identifier' => 'PositionTitle',
										'text' => $data_official_job_title
									), 
									// Primary Department
									array (
										'type' => 'asset',
										'identifier' => 'OrganizationalUnitPrimary',
										'assetType' => 'page',
										'pagePath' => $data_primary_department_path
									), 
								)								
							) 
						), //End PositionInfo Group									

						// Contact Info Group
						array (
							'type' => 'group',
							'identifier' => 'ContactMethod',
							'structuredDataNodes' => array (
								'structuredDataNode' => array (
									// Email
									array (
										'type' => 'text',
										'identifier' => 'InternetEmailAddress',
										'text' => $data_email_address
									),
									
									// Telephone Group
									array (
										'type' => 'group',
										'identifier' => 'Telephone',
										'structuredDataNodes' => array (
											'structuredDataNode' => array (
												// International Country Code
												array (
													'type' => 'text',
													'identifier' => 'InternationalCountryCode',
													'text' => $data_telephone_international_country_code
												),
												// National Number
												array (
													'type' => 'text', 
													'identifier' => 'NationalNumber',
													'text' => $data_telephone_national_number
												),
												// Area Code
												array (
													'type' => 'text',
													'identifier' => 'AreaCityCode',
													'text' => $data_telephone_area_city_code
												),
												// Subscriber Number
												array (
													'type' => 'text',
													'identifier' => 'SubscriberNumber',
													'text' => $data_telephone_subscriber_number
												),
												// Extension
												array (
													'type' => 'text',
													'identifier' => 'Extension',
													'text' => $data_telephone_extension
												),
											)
										) 
									), // End Telephone Group
									
									// Fax Group
									array (
										'type' => 'group',
										'identifier' => 'Fax',
										'structuredDataNodes' => array (
											'structuredDataNode' => array (
												// International Country Code
												array (
													'type' => 'text',
													'identifier' => 'InternationalCountryCode',
													'text' => $data_fax_international_country_code
												),
												// National Number
												array (
													'type' => 'text', 
													'identifier' => 'NationalNumber',
													'text' => $data_fax_national_number
												),
												// Area Code
												array (
													'type' => 'text',
													'identifier' => 'AreaCityCode',
													'text' => $data_fax_area_city_code
												),
												// Subscriber Number
												array (
													'type' => 'text',
													'identifier' => 'SubscriberNumber',
													'text' => $data_fax_subscriber_number
												),
												// Extension
												array (
													'type' => 'text',
													'identifier' => 'Extension',
													'text' => $data_fax_extension
												),
											)
										) 
									), // End Fax Group		
									
									// Address Group
									array (
										'type' => 'group',
										'identifier' => 'PostalAddress',
										'structuredDataNodes' => array (
											'structuredDataNode' => array (
												// Building and Room
												array (
													'type' => 'text', 
													'identifier' => 'buildingRoom',
													'text' => $data_building_room
												),
												// Mailstop
												array (
													'type' => 'text',
													'identifier' => 'Mailstop',
													'text' => $data_mail_stop_number
												),
												// Address Line
												array (
													'type' => 'text',
													'identifier' => 'AddressLine',
													'text' => $data_address_line
												),
												// City
												array (
													'type' => 'text',
													'identifier' => 'Municipality',
													'text' => $data_municipality
												),
												// Region
												array (
													'type' => 'text',
													'identifier' => 'Region',
													'text' => $data_region
												),
												// Postal Code
												array (
													'type' => 'text',
													'identifier' => 'PostalCode',
													'text' => $data_postal_code
												),
												// Country Code
												array (
													'type' => 'text',
													'identifier' => 'CountryCode',
													'text' => $data_country_code
												),
											)
										) 
									), // End Address Group	
									
									// Privacy Group
									array (
										'type' => 'group',
										'identifier' => 'Privacy',
										'structuredDataNodes' => array (
											'structuredDataNode' => array (
												// Show Email?
												array (
													'type' => 'text', 
													'identifier' => 'EmailExternal',
													'text' => 'yes'
												),
												// Show Phone?
												array (
													'type' => 'text',
													'identifier' => 'TelephoneExternal',
													'text' => 'yes'
												),
												// Show Buildign and Room Number?
												array (
													'type' => 'text',
													'identifier' => 'BuildingRoomExternal',
													'text' => 'yes'
												),
												// Show Mailing Address?
												array (
													'type' => 'text',
													'identifier' => 'PostalAddressExternal',
													'text' => 'yes'
												),
											)
										) 
									) ,// End Privacy Group							
								)
							)
						), // End Contact Info Group
						
					) // End StructuredDataNode
					
				) // End StructuredDataNodes
				
			) // End StructuredData
			
		) // End Page
		
	); // End Asset
	
	$params = array( 'authentication' => $auth,
					'asset' => $asset );
	
	try {
		$out = $service->create($params);
		
		if ( $out->createReturn->success != 'true' ) {
			$failedCount++;
			$log .= "Failed to create asset.<br/>";
			$log .= $out->createReturn->message . "<br/><br/>";
		}
		else
		{
			$log .= "Successful creation of asset.<br/><br/>";
		}
	}
	
	catch (Exception $e) {
		$log .= "WSDL creation error on asset:<br/>";
		$log .= $e->getMessage() . "<br/><br/>";
	}

	echo $log;
?>

</body>
</html>
