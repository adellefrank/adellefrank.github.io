<?php
	if ($which_access == 'full') {
		// Full Access for college_editor_atlas
		$set_access = array(
			array(
				'level' => 'write',
				'type' => 'group',
				'name' => 'college_managers'
			),
			array(
				'level' => 'write',
				'type' => 'group',
				'name' => 'college_publishers'
			),
			array(
				'level' => 'write',
				'type' => 'group',
				'name' => 'college_editor_atlas'
			),
		);
	} else {	
		// Limited Access for college_editor_atlas
		$set_access = array(
			array(
				'level' => 'write',
				'type' => 'group',
				'name' => 'college_managers'
			),
			array(
				'level' => 'write',
				'type' => 'group',
				'name' => 'college_publishers'
			),
			array(
				'level' => 'read',
				'type' => 'group',
				'name' => 'college_editor_atlas'
			),
		);
	}

$access = array(
	'identifier' => $id,
	'aclEntries' => array(
		'aclEntry' => $set_access
	),
	'allLevel' => 'none',
);


$access_params = array( 'authentication' => $auth,
		'accessRightsInformation' => $access,
		'applyToChildren' => true );

try {
	$edit_access = $service->editAccessRights($access_params);
												
	if ( $edit_access->editAccessRightsReturn->success != 'true' ) {
		$log .= '<h1 style="color:red;">Failed to change access.</h1>';
		$log .= "<p>" .$edit_access->editAccessRightsReturn->message . "</p>";
	} else {
		//$log .= '<h1>Access changed.</h1>';
	}
}

catch (Exception $access_e) {
	$log .= '<h1 style="color:red;">WSDL error on access:</h1>';
	$log .= "<p>" . $access_e->getMessage() . "</p>";
}
?>