<?php
	switch ($data_subject) {
		case 'AAS':
			$data_subject_full_name = 'African American Studies';
			$data_subject_folder_name = 'african_american';
			break;
		case 'AFS':
			$data_subject_full_name = 'African Studies';
			$data_subject_folder_name = 'african';
			break;
		case 'AMST':
			$data_subject_full_name = 'American Studies';
			$data_subject_folder_name = 'american';
			break;
		case 'ANCMED':
			$data_subject_full_name = 'Ancient Mediterranean Studies';
			$data_subject_folder_name = 'ancient_mediterranean';
			break;
		case 'ANT':
			$data_subject_full_name = 'Anthropology';
			$data_subject_folder_name = 'anthropology';
			break;
		case 'ARAB':
			$data_subject_full_name = 'Arabic';
			$data_subject_folder_name = 'arabic';
			break;
		case 'ARTHIST':
			$data_subject_full_name = 'Art History';
			$data_subject_folder_name = 'art_history';
			break;
		case 'ARTVIS':
			$data_subject_full_name = 'Visual Arts';
			$data_subject_folder_name = 'visual_arts';
			break;
		case 'ASIA':
			$data_subject_full_name = 'Asian Studies';
			$data_subject_folder_name = 'asian';
			break;
		case 'BIOL':
			$data_subject_full_name = 'Biology';
			$data_subject_folder_name = 'biology';
			break;
		case 'CBSC':
			$data_subject_full_name = 'Community Building and Social Change';
			$data_subject_folder_name = 'community_building';
			break;			
		case 'CHEM':
			$data_subject_full_name = 'Chemistry';
			$data_subject_folder_name = 'chemistry';
			break;
		case 'CHN':
			$data_subject_full_name = 'Chinese';
			$data_subject_folder_name = 'chinese';
			break;
		case 'CL':
			$data_subject_full_name = 'Classics';
			$data_subject_folder_name = 'classics';
			break;
		case 'CPLT':
			$data_subject_full_name = 'Comparative Literature';
			$data_subject_folder_name = 'comparative_literature';
			break;
		case 'CS':
			$data_subject_full_name = 'Computer Science';
			$data_subject_folder_name = 'computer_science';
			break;
		case 'DANC':
			$data_subject_full_name = 'Dance';
			$data_subject_folder_name = 'dance';
			break;
		case 'DUTCH':
			$data_subject_full_name = 'Dutch';
			$data_subject_folder_name = 'dutch';
			break;
		case 'EAS':
			$data_subject_full_name = 'East Asian Studies';
			$data_subject_folder_name = 'east_asian';
			break;
		case 'ECON':
			$data_subject_full_name = 'Economics';
			$data_subject_folder_name = 'economics';
			break;
		case 'ECFS':
			$data_subject_full_name = 'Freshman Seminar';
			$data_subject_folder_name = 'freshman_seminar';
			break;	
		case 'EDS':
			$data_subject_full_name = 'Educational Studies';
			$data_subject_folder_name = 'education';
			break;
		case 'ENG':
			$data_subject_full_name = 'English';
			$data_subject_folder_name = 'english';
			break;
			case 'ENGCW':
			$data_subject_full_name = 'Creative Writing';
			$data_subject_folder_name = 'creative_writing';
			break;
		case 'ENVS':
			$data_subject_full_name = 'Environmental Studies';
			$data_subject_folder_name = 'environmental';
			break;
		case 'FILM':
			$data_subject_full_name = 'Film Studies';
			$data_subject_folder_name = 'film';
			break;
		case 'FREN':
			$data_subject_full_name = 'French';
			$data_subject_folder_name = 'french';
			break;
		case 'GER':
			$data_subject_full_name = 'German';
			$data_subject_folder_name = 'german';
			break;
		case 'GHCS':
			$data_subject_full_name = 'Global Health, Culture, and Society';
			$data_subject_folder_name = 'global_health';
			break;
		case 'GRK':
			$data_subject_full_name = 'Greek';
			$data_subject_folder_name = 'greek';
			break;
		case 'HEBR':
			$data_subject_full_name = 'Hebrew';
			$data_subject_folder_name = 'hebrew';
			break;
		case 'HIST':
			$data_subject_full_name = 'History';
			$data_subject_folder_name = 'history';
			break;
		case 'HNDI':
			$data_subject_full_name = 'Hindi';
			$data_subject_folder_name = 'hindi';
			break;
		case 'IDS':
			$data_subject_full_name = 'Interdisciplinary Studies in Culture and Society';
			$data_subject_folder_name = 'interdisciplinary';
			break;
		case 'ITAL':
			$data_subject_full_name = 'Italian';
			$data_subject_folder_name = 'italian';
			break;
		case 'JPN':
			$data_subject_full_name = 'Japanese';
			$data_subject_folder_name = 'japanese';
			break;
		case 'JRNL':
			$data_subject_full_name = 'Journalism';
			$data_subject_folder_name = 'journalism';
			break;
		case 'JS':
			$data_subject_full_name = 'Jewish Studies';
			$data_subject_folder_name = 'jewish';
			break;
		case 'KRN':
			$data_subject_full_name = 'Korean';
			$data_subject_folder_name = 'korean';
			break;
		case 'LACS':
			$data_subject_full_name = 'Latin American and Caribbean Studies';
			$data_subject_folder_name = 'latin_american_caribbean';
			break;
		case 'LAS':
			$data_subject_full_name = 'Latin American and Caribbean Studies';
			$data_subject_folder_name = 'latin_american_caribbean';
			break;			
		case 'LAT':
			$data_subject_full_name = 'Latin';
			$data_subject_folder_name = 'latin';
			break;
		case 'LING':
			$data_subject_full_name = 'Linguistics';
			$data_subject_folder_name = 'linguistics';
			break;
		case 'MATH':
			$data_subject_full_name = 'Mathematics';
			$data_subject_folder_name = 'mathematics';
			break;
		case 'MESAS':
			$data_subject_full_name = 'Middle Eastern and South Asian Studies';
			$data_subject_folder_name = 'middle_eastern_south_asian';
			break;
		case 'MUS':
			$data_subject_full_name = 'Music';
			$data_subject_folder_name = 'music';
			break;
		case 'NBB':
			$data_subject_full_name = 'Neuroscience and Behavioral Biology';
			$data_subject_folder_name = 'neuroscience_behavioral_biology';
			break;
		case 'PACE':
			$data_subject_full_name = 'PACE (Pre-Major Advising Connections at Emory)';
			$data_subject_folder_name = 'premajor';
			break;
		case 'PE':
			$data_subject_full_name = 'Physical Education and Health';
			$data_subject_folder_name = 'physical_education_health';
			break;
		case 'PERS':
			$data_subject_full_name = 'Persian';
			$data_subject_folder_name = 'persian';
			break;
		case 'PHIL':
			$data_subject_full_name = 'Philosophy';
			$data_subject_folder_name = 'philosophy';
			break;
		case 'PHYS':
			$data_subject_full_name = 'Physics';
			$data_subject_folder_name = 'physics';
			break;
		case 'POLS':
			$data_subject_full_name = 'Political Science';
			$data_subject_folder_name = 'political_science';
			break;
		case 'PORT':
			$data_subject_full_name = 'Portuguese';
			$data_subject_folder_name = 'portuguese';
			break;
		case 'PSYC':
			$data_subject_full_name = 'Psychology';
			$data_subject_folder_name = 'psychology';
			break;
		case 'REALC':
			$data_subject_full_name = 'Russian and East Asian Languages and Cultures';
			$data_subject_folder_name = 'russian_east_asian';
			break;
		case 'REES':
			$data_subject_full_name = 'Russian and East European Studies';
			$data_subject_folder_name = 'russian_east_european';
			break;
		case 'REL':
			$data_subject_full_name = 'Religion';
			$data_subject_folder_name = 'religion';
			break;
		case 'RUSS':
			$data_subject_full_name = 'Russian';
			$data_subject_folder_name = 'russian';
			break;
		case 'SNSK':
			$data_subject_full_name = 'Sanskrit';
			$data_subject_folder_name = 'sanskrit';
			break;
		case 'SOC':
			$data_subject_full_name = 'Sociology';
			$data_subject_folder_name = 'sociology';
			break;
		case 'SPAN':
			$data_subject_full_name = 'Spanish';
			$data_subject_folder_name = 'spanish';
			break;
		case 'TBT':
			$data_subject_full_name = 'Tibetan';
			$data_subject_folder_name = 'tibetan';
			break;
		case 'THEA':
			$data_subject_full_name = 'Theater Studies';
			$data_subject_folder_name = 'theater';
			break;
		case 'WS':
			$data_subject_full_name = "Women's Studies";
			$data_subject_folder_name = 'womens';
			break;
		case 'YDD':
			$data_subject_full_name = 'Yiddish';
			$data_subject_folder_name = 'yiddish';
			break;																																																								
		default:
			$data_subject_full_name = 'OTHER';
			$data_subject_folder_name = 'other';
	}

?>