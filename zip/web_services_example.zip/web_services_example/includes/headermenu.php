<?php

	echo '<div class="headermenu"><a href="../atlas/"><img src="../images/green_arrow_menu.png" width="30" height="26" border="0"/><span style="vertical-align:bottom; padding:3px;">Return to the Menu</span></a></div>';
	
?>