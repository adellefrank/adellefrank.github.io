<?
	$primary_department_path_root ='college/test/academic/department/';
	$data_primary_department_path = $primary_department_path_root;
	switch ($data_primary_department) {
		case 'Administration':
			$data_primary_department_path = '';
			break;
		case 'African American Studies':
			$data_primary_department_path .= 'african_american';
			break;
		case 'Anthropology':
			$data_primary_department_path .= 'anthropology';
			break;
		case 'Art History':
			$data_primary_department_path .= 'art_history';
			break;
		case 'Visual Arts':
			$data_primary_department_path .= 'visual_arts';
			break;
		case 'Biology':
			$data_primary_department_path .= 'biology';
			break;
		case 'Center for Science Education':
			$data_primary_department_path = '';
			break;
		case 'Center For Teaching and Curriculum':
			$data_primary_department_path = '';
			break;
		case 'Chemistry':
			$data_primary_department_path .= 'chemistry';
			break;
		case 'Classics':
			$data_primary_department_path .= 'classics';
			break;
		case 'Comparative Literature':
			$data_primary_department_path .= 'comparative_literature';
			break;
		case 'Creative Writing':
			$data_primary_department_path .= 'creative_writing';
			break;
		case 'Ctr For The Study of Public Scholarship':
			$data_primary_department_path .= '';
			break;
		case 'Deleted':
			$data_primary_department_path = '';
			break;
		case 'Economics':
			$data_primary_department_path .= 'economics';
			break;
		case 'Educational Studies':
			$data_primary_department_path .= 'education';
			break;
		case 'English':
			$data_primary_department_path .= 'english';
			break;
		case 'Environmental Studies':
			$data_primary_department_path .= 'environmental_science';
			break;
		case 'Film Studies':
			$data_primary_department_path .= 'film';
			break;
		case 'French And Italian':
			$data_primary_department_path .= 'french_italian';
			break;
		case 'Italian':
			$data_primary_department_path .= 'italian';
			break;
		case 'German Studies':
			$data_primary_department_path .= 'german';
			break;
		case 'Health & Physical Education':
			$data_primary_department_path .= 'physical_education_health';
			break;
		case 'History':
			$data_primary_department_path .= 'history';
			break;
		case 'Humanities Center':
			$data_primary_department_path = '';
			break;
		case "Institute For Comparative & Int'l Stud":
			$data_primary_department_path = '';
			break;
		case 'Institute for the Study of Modern Israel':
			$data_primary_department_path = '';
			break;
		case 'Institute of Jewish Studies':
			$data_primary_department_path .= 'jewish';
			break;
		case 'Institute of Liberal Arts':
			$data_primary_department_path .= 'institute_liberal_arts';
			break;
		case 'Journalism Program':
			$data_primary_department_path .= 'journalism';
			break;
		case 'Mathematics And Computer Science':
			$data_primary_department_path .= 'mathematics_computer_science';
			break;
		case 'Middle Eastern And South Asian Studies':
			$data_primary_department_path .= 'middle_eastern_south_asian';
			break;
		case 'Music':
			$data_primary_department_path .= 'music';
			break;
		case 'Neuroscience & Behavioral Biology Prog':
			$data_primary_department_path .= 'neuroscience_behavioral_biology';
			break;
		case 'Office for Undergraduate Education':
			$data_primary_department_path .= '';
			break;
		case 'Philosophy':
			$data_primary_department_path .= 'philosophy';
			break;
		case 'Physics':
			$data_primary_department_path .= 'physics';
			break;
		case 'Political Science':
			$data_primary_department_path .= 'political_science';
			break;
		case 'Psychology':
			$data_primary_department_path .= 'psychology';
			break;
		case 'Religion':
			$data_primary_department_path .= 'religion';
			break;
		case 'Russian, E Asian Lang & Cult (REALC)':
			$data_primary_department_path .= 'russian_east_asian';
			break;
		case 'Sociology':
			$data_primary_department_path .= 'sociology';
			break;
		case 'Spanish':
			$data_primary_department_path .= 'spanish_portuguese';
			break;
		case 'Theater Studies':
			$data_primary_department_path .= 'theater';
			break;
		case 'Theatre Emory':
			$data_primary_department_path .= 'theater';
			break;
		case "Women's Studies":
			$data_primary_department_path .= 'womens';
			break;
		default:
			$data_primary_department_path = '';
	}

?>