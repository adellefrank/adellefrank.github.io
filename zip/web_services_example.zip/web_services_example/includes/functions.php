<?php
	function string_begins_with($string, $search) {
		return (strncmp($string, $search, strlen($search)) == 0);
	}

	function beginsWith( $str, $sub ) {
		return ( substr( $str, 0, strlen( $sub ) ) === $sub );
	}
	
	function endsWith( $str, $sub ) {
		return ( substr( $str, strlen( $str ) - strlen( $sub ) ) === $sub );
	}

    function get_department($dept_abbrev, $returnValue) {			
		
		switch ($dept_abbrev) {
			case 'AAS':
				$folder_name = 'african_american';
				$folder_name_desc = 'African American Studies';
				break;
			case 'AFS':
				$folder_name = 'african';
				$folder_name_desc = 'African Studies';
				break;
			case 'AMST':
				$folder_name = 'american';
				$folder_name_desc = 'American Studies';
				break;
			case 'ANCMED':
				$folder_name = 'ancient_mediterranean';
				$folder_name_desc = 'Ancient Mediterranean Studies';
				break;
			case 'ANT':
				$folder_name = 'anthropology';
				$folder_name_desc = 'Anthropology';
				break;
			case 'ARAB':
				$folder_name = 'arabic';
				$folder_name_desc = 'Arabic';
				break;
			case 'ARTHIST':
				$folder_name = 'art_history';
				$folder_name_desc = 'Art History';
				break;
			case 'ARTVIS':
				$folder_name = 'visual_arts';
				$folder_name_desc = 'Visual Arts';
				break;
			case 'ASIA':
				$folder_name = 'asian';
				$folder_name_desc = 'Asian Studies';
				break;
			case 'BIOL':
				$folder_name = 'biology';
				$folder_name_desc = 'Biology';
				break;
			case 'CBSC':
				$folder_name = 'community_building';
				$folder_name_desc = 'Community Building and Social Change';
				break;			
			case 'CHEM':
				$folder_name = 'chemistry';
				$folder_name_desc = 'Chemistry';
				break;
			case 'CHN':
				$folder_name = 'chinese';
				$folder_name_desc = 'Chinese';
				break;
			case 'CL':
				$folder_name = 'classics';
				$folder_name_desc = 'Classics';
				break;
			case 'CPLT':
				$folder_name = 'comparative_literature';
				$folder_name_desc = 'Comparative Literature';
				break;
			case 'CS':
				$folder_name = 'computer_science';
				$folder_name_desc = 'Computer Science';
				break;
			case 'DANC':
				$folder_name = 'dance';
				$folder_name_desc = 'Dance';
				break;
			case 'DUTCH':
				$folder_name = 'dutch';
				$folder_name_desc = 'Dutch';
				break;
			case 'EAS':
				$folder_name = 'east_asian';
				$folder_name_desc = 'East Asian Studies';
				break;
			case 'ECON':
				$folder_name = 'economics';
				$folder_name_desc = 'Economics';
				break;
			case 'ECFS':
				$folder_name = 'freshman_seminar';
				$folder_name_desc = 'Freshman Seminar';
				break;
			case 'EDS':
				$folder_name = 'education';
				$folder_name_desc = 'Educational Studies';
				break;
			case 'ENG':
				$folder_name = 'english';
				$folder_name_desc = 'English';
				break;
			case 'ENGCW':
				$folder_name = 'creative_writing';
				$folder_name_desc = 'Creative Writing';
				break;
			case 'ENVS':
				$folder_name = 'environmental';
				$folder_name_desc = 'Environmental Studies';
				break;
			case 'FILM':
				$folder_name = 'film';
				$folder_name_desc = 'Film Studies';
				break;
			case 'FREN':
				$folder_name = 'french';
				$folder_name_desc = 'French';
				break;
			case 'GER':
				$folder_name = 'german';
				$folder_name_desc = 'German';
				break;
			case 'GHCS':
				$folder_name = 'global_health';
				$folder_name_desc = 'Global Health, Culture, and Society';
				break;
			case 'GRK':
				$folder_name = 'greek';
				$folder_name_desc = 'Greek';
				break;
			case 'HEBR':
				$folder_name = 'hebrew';
				$folder_name_desc = 'Hebrew';
				break;
			case 'HIST':
				$folder_name = 'history';
				$folder_name_desc = 'History';
				break;
			case 'HNDI':
				$folder_name = 'hindi';
				$folder_name_desc = 'Hindi';
				break;
			case 'IDS':
				$folder_name = 'interdisciplinary';
				$folder_name_desc = 'Institute of Liberal Arts';
				break;
			case 'ITAL':
				$folder_name = 'italian';
				$folder_name_desc = 'Italian';
				break;
			case 'JPN':
				$folder_name = 'japanese';
				$folder_name_desc = 'Japanese';
				break;
			case 'JRNL':
				$folder_name = 'journalism';
				$folder_name_desc = 'Journalism';
				break;
			case 'JS':
				$folder_name = 'jewish';
				$folder_name_desc = 'Jewish Studies';
				break;
			case 'KRN':
				$folder_name = 'korean';
				$folder_name_desc = 'Korean';
				break;
			case 'LACS':
				$folder_name = 'latin_american_caribbean';
				$folder_name_desc = 'Latin American and Caribbean Studies';
				break;
			case 'LAS':
				$folder_name = 'latin_american_caribbean';
				$folder_name_desc = 'Latin American and Caribbean Studies';
				break;			
			case 'LAT':
				$folder_name = 'latin';
				$folder_name_desc = 'Latin';
				break;
			case 'LING':
				$folder_name = 'linguistics';
				$folder_name_desc = 'Linguistics';
				break;
			case 'MATH':
				$folder_name = 'mathematics';
				$folder_name_desc = 'Mathematics';
				break;
			case 'MESAS':
				$folder_name = 'middle_eastern_south_asian';
				$folder_name_desc = 'Middle Eastern and South Asian Studies';
				break;
			case 'MUS':
				$folder_name = 'music';
				$folder_name_desc = 'Music';
				break;
			case 'NBB':
				$folder_name = 'neuroscience_behavioral_biology';
				$folder_name_desc = 'Neuroscience and Behavioral Biology';
				break;
			case 'PACE':
				$folder_name = 'premajor';
				$folder_name_desc = 'PACE (Pre-Major Advising Connections at Emory)';
				break;
			case 'PE':
				$folder_name = 'physical_education_health';
				$folder_name_desc = 'Physical Education and Health';
				break;
			case 'PERS':
				$folder_name = 'persian';
				$folder_name_desc = 'Persian';
				break;
			case 'PHIL':
				$folder_name = 'philosophy';
				$folder_name_desc = 'Philosophy';
				break;
			case 'PHYS':
				$folder_name = 'physics';
				$folder_name_desc = 'Physics';
				break;
			case 'POLS':
				$folder_name = 'political_science';
				$folder_name_desc = 'Political Science';
				break;
			case 'PORT':
				$folder_name = 'portuguese';
				$folder_name_desc = 'Portuguese';
				break;
			case 'PSYC':
				$folder_name = 'psychology';
				$folder_name_desc = 'Psychology';
				break;
			case 'REALC':
				$folder_name = 'russian_east_asian';
				$folder_name_desc = 'Russian and East Asian Languages and Cultures';
				break;
			case 'REES':
				$folder_name = 'russian_east_european';
				$folder_name_desc = 'Russian and East European Studies';
				break;
			case 'REL':
				$folder_name = 'religion';
				$folder_name_desc = 'Religion';
				break;
			case 'RUSS':
				$folder_name = 'russian';
				$folder_name_desc = 'Russian';
				break;
			case 'SNSK':
				$folder_name = 'sanskrit';
				$folder_name_desc = 'Sanskrit';
				break;
			case 'SOC':
				$folder_name = 'sociology';
				$folder_name_desc = 'Sociology';
				break;
			case 'SPAN':
				$folder_name = 'spanish';
				$folder_name_desc = 'Spanish';
				break;
			case 'TBT':
				$folder_name = 'tibetan';
				$folder_name_desc = 'Tibetan';
				break;
			case 'THEA':
				$folder_name = 'theater';
				$folder_name_desc = 'Theater Studies';
				break;
			case 'WS':
				$folder_name = 'womens';
				$folder_name_desc = "Women's Studies";
				break;
			case 'YDD':
				$folder_name = 'yiddish';
				$folder_name_desc = 'Yiddish';
				break;																																																								
			default:
				$folder_name = 'other';
				$folder_name_desc = 'OTHER';
		}
		
		if ($returnValue == 'desc') {
			return($folder_name_desc);
		} else {
	        return($folder_name); 
		}
	}
	
    function get_department_system_name($dept_name) {			
		
		switch ($dept_name) {
			case 'Administration':
			$system_name = '';
			break;
		case 'African Studies':
			$system_name = 'african';
			break;
		case 'American Studies':
			$system_name = 'american';
			break;
		case 'Ancient Mediterranean Studies':
			$system_name = 'ancient_mediterranean';
			break;
		case 'African American Studies':
			$system_name = 'african_american';
			break;
		case 'Anthropology':
			$system_name = 'anthropology';
			break;
		case 'Art History':
			$system_name = 'art_history';
			break;
		case 'Visual Arts':
			$system_name = 'visual_arts';
			break;
		case 'Biology':
			$system_name = 'biology';
			break;
		case 'Center for Science Education':
			$system_name = '';
			break;
		case 'Center For Teaching and Curriculum':
			$system_name = '';
			break;
		case 'Chemistry':
			$system_name = 'chemistry';
			break;
		case 'Classics':
			$system_name = 'classics';
			break;
		case 'Comparative Literature':
			$system_name = 'comparative_literature';
			break;
		case 'Creative Writing':
			$system_name = 'creative_writing';
			break;
		case 'Ctr For The Study of Public Scholarship':
			$system_name = '';
			break;
		case 'Dance':
			$system_name = 'theater_dance';
			break;
		case 'Deleted':
			$system_name = '';
			break;
		case 'Economics':
			$system_name = 'economics';
			break;
		case 'Educational Studies':
			$system_name = 'education';
			break;
		case 'English':
			$system_name = 'english';
			break;
		case 'Environmental Studies':
			$system_name = 'environmental';
			break;
		case 'Film Studies':
			$system_name = 'film';
			break;
		case 'French And Italian':
			$system_name = 'french_italian';
			break;
		case 'Italian':
			$system_name = 'italian';
			break;
		case 'Freshman Seminar':
			$system_name = 'freshman_seminar';
			break;
		case 'German Studies':
			$system_name = 'german';
			break;
		case 'Global Health':
			$system_name = 'global_health';
			break;
		case 'Health & Physical Education':
			$system_name = 'physical_education_health';
			break;
		case 'History':
			$system_name = 'history';
			break;
		case 'Humanities Center':
			$system_name = '';
			break;
		case 'Humanities Center':
			$system_name = '';
			break;
		case "Institute For Comparative & Int'l Stud":
			$system_name = '';
			break;
		case 'Institute for the Study of Modern Israel':
			$system_name = '';
			break;
		case 'Institute of Jewish Studies':
			$system_name = 'jewish';
			break;
		case 'Institute of Liberal Arts':
			$system_name = 'institute_liberal_arts';
			break;
		case 'Irish Studies':
			$system_name = 'irish';
			break;
		case 'Jewish Studies':
			$system_name = 'jewish';
			break;
		case 'Journalism Program':
			$system_name = 'journalism';
			break;
		case 'LACS':
			$system_name = 'latin_american_caribbean';
			break;
		case 'Linguistics':
			$system_name = 'linguistics';
			break;
		case 'Mathematics And Computer Science':
			$system_name = 'mathematics_computer_science';
			break;
		case 'Middle Eastern And South Asian Studies':
			$system_name = 'middle_eastern_south_asian';
			break;
		case 'Music':
			$system_name = 'music';
			break;
		case 'Neuroscience & Behavioral Biology Prog':
			$system_name = 'neuroscience_behavioral_biology';
			break;
		case 'Office for Undergraduate Education':
			$system_name = '';
			break;
		case 'Philosophy':
			$system_name = 'philosophy';
			break;
		case 'Physics':
			$system_name = 'physics';
			break;
		case 'Political Science':
			$system_name = 'political_science';
			break;
		case 'Psychology':
			$system_name = 'psychology';
			break;
		case 'Religion':
			$system_name = 'religion';
			break;
		case 'Russian, E Asian Lang & Cult (REALC)':
			$system_name = 'russian_east_asian';
			break;
		case 'Sociology':
			$system_name = 'sociology';
			break;
		case 'Spanish':
			$system_name = 'spanish_portuguese';
			break;
		case 'Theater Studies':
			$system_name = 'theater_dance';
			break;
		case 'Theatre Emory':
			$system_name = 'theater_dance';
			break;
		case "Women's Studies":
			$system_name = 'womens';
			break;
		default:
			$system_name = '';
		}
				
        return($system_name); 
	}	
	
	
	function get_department_desc($dept_system_name) {			
		
		switch ($dept_system_name) {
		case 'african':
			$dept_desc = 'African Studies';
			break;
		case 'american':
			$dept_desc = 'American Studies';
			break;
		case 'ancient_mediterranean':
			$dept_desc = 'Ancient Mediterranean Studies';
			break;
		case 'african_american':
			$dept_desc = 'African American Studies';
			break;
		case 'anthropology':
			$dept_desc = 'Anthropology';
			break;
		case 'art_history':
			$dept_desc = 'Art History';
			break;
		case 'visual_arts':
			$dept_desc = 'Visual Arts';
			break;
		case 'biology':
			$dept_desc = 'Biology';
			break;
		case 'chemistry':
			$dept_desc = 'Chemistry';
			break;
		case 'classics':
			$dept_desc = 'Classics';
			break;
		case 'comparative_literature':
			$dept_desc = 'Comparative Literature';
			break;
		case 'creative_writing':
			$dept_desc = 'Creative Writing';
			break;
		case 'economics':
			$dept_desc = 'Economics';
			break;
		case 'education':
			$dept_desc = 'Educational Studies';
			break;
		case 'english':
			$dept_desc = 'English';
			break;
		case 'environmental':
			$dept_desc = 'Environmental Studies';
			break;
		case 'film':
			$dept_desc = 'Film Studies';
			break;
		case 'french_italian':
			$dept_desc = 'French and Italian';
			break;
		case 'italian':
			$dept_desc = 'Italian';
			break;
		case 'freshman_seminar':
			$dept_desc = 'Freshman Seminar';
			break;
		case 'german':
			$dept_desc = 'German Studies';
			break;
		case 'global_health':
			$dept_desc = 'Global Health, Society and Culture';
			break;
		case 'physical_education_health':
			$dept_desc = 'Health and Physical Education';
			break;
		case 'history':
			$dept_desc = 'History';
			break;
		case 'interdisciplinary':
			$dept_desc = 'Interdisciplinary Studies';
			break;
		case 'irish':
			$dept_desc = 'Irish Studies';
			break;
		case 'jewish':
			$dept_desc = 'Jewish Studies';
			break;
		case 'journalism':
			$dept_desc = 'Journalism';
			break;
		case 'latin_american_caribbean':
			$dept_desc = 'Latin American and Caribbean Studies';
			break;
		case 'linguistics':
			$dept_desc = 'Linguistics';
			break;
		case 'mathematics_computer_science':
			$dept_desc = 'Mathematics and Computer Science';
			break;
		case 'middle_eastern_south_asian':
			$dept_desc = 'Middle Eastern and South Asian Studies';
			break;
		case 'music':
			$dept_desc = 'Music';
			break;
		case 'neuroscience_behavioral_biology':
			$dept_desc = 'Neuroscience and Behavioral Biology';
			break;
		case 'philosophy':
			$dept_desc = 'Philosophy';
			break;
		case 'physics':
			$dept_desc = 'Physics';
			break;
		case 'political_science':
			$dept_desc = 'Political Science';
			break;
		case 'psychology':
			$dept_desc = 'Psychology';
			break;
		case 'religion':
			$dept_desc = 'Religion';
			break;
		case 'russian_east_asian':
			$dept_desc = 'Russian and East Asian Languages and Culture (REALC)';
			break;
		case 'sociology':
			$dept_desc = 'Sociology';
			break;
		case 'spanish_portuguese':
			$dept_desc = 'Spanish and Portuguese';
			break;
		case 'theater_dance':
			$dept_desc = 'Theater Studies and Dance';
			break;
		case 'womens':
			$dept_desc = "Women's Studies";
			break;
		case 'visual_arts':
			$dept_desc = "Visual Arts";
			break;
		default:
			$dept_desc = '';
		}
				
        return($dept_desc); 
	}	
	
	
	
	function get_ger_desc($ger) {			
		
		switch ($ger) {
		case 'fsem':
			$ger_desc = 'First-Year Seminar Classes (FSEM) Courses for GER requirement - Area I';
			break;
		case 'fwrt':
			$ger_desc = 'First-Year Writing Requirement (FWRT) Courses for GER requirement - Area II';
			break;
		case 'hal':
			$ger_desc = 'Humanities, Arts, Language (HAL) Courses for GER requirement - Area VII';
			break;
		case 'hal_hap':
			$ger_desc = 'Humanities, Arts, Performance (HAP) & (HAL) Courses for GER requirement - Area VII';
			break;
		case 'hap':
			$ger_desc = 'Humanities, Arts, Performance (HAP) Courses for GER requirement - Area VII';
			break;
		case 'hsc':
			$ger_desc = 'History, Society, Cultures (HSC) Courses for GER requirement - Area VI';
			break;
		case 'hth':
			$ger_desc = 'Personal Health (HTH) Courses for GER requirement - Area VIII';
			break;
		case 'mqr':
			$ger_desc = 'Math & Quantitative Reasoning (MQR) Courses for GER requirement - Area IV';
			break;
		case 'ped':
			$ger_desc = 'Physical Education and Dance (PED) Courses for GER requirement - Area IX';
			break;
		case 'snt':
			$ger_desc = 'Science, Nature, Technology (SNT) Courses for GER requirement - Area V';
			break;
		case 'wrt':
			$ger_desc = 'WRT (Continuing Writing) Courses for GER requirement - Area III ';
			break;
		default:
			$ger_desc = '';
		}
				
        return($ger_desc); 
	}	
	
	
	function get_associated_subjects($thisDepartment) {
		
		switch ($thisDepartment) {
		case 'african':
			$assoc_subjects = array('AFS');
			break;
		case 'american':
			$assoc_subjects = array('AMST');
			break;
		case 'ancient_mediterranean':
			$assoc_subjects = array('ANCMED');
			break;
		case 'african_american':
			$assoc_subjects = array('AAS');
			break;
		case 'anthropology':
			$assoc_subjects = array('ANT','GHCS');
			break;
		case 'art_history':
			$assoc_subjects = array('ARTHIST');
			break;
		case 'visual_arts':
			$assoc_subjects = array('ARTVIS');
			break;
		case 'biology':
			$assoc_subjects = array('BIOL');
			break;
		case 'chemistry':
			$assoc_subjects = array('CHEM');
			break;
		case 'classics':
			$assoc_subjects = array('ANCMED','CL','GRK','LAT');
			break;
		case 'comparative_literature':
			$assoc_subjects = array('CPLT');
			break;
		case 'creative_writing':
			$assoc_subjects = array('ENG', 'ENGCW');
			break;
		case 'dance':
			$assoc_subjects = array('DANC');
			break;
		case 'economics':
			$assoc_subjects = array('ECON');
			break;
		case 'education':
			$assoc_subjects = array('EDS');
			break;
		case 'english':
			$assoc_subjects = array('ENG');
			break;
		case 'environmental':
			$assoc_subjects = array('ENVS');
			break;
		case 'film':
			$assoc_subjects = array('FILM');
			break;
		case 'french_italian':
			$assoc_subjects = array('FREN','ITAL');
			break;
		case 'italian':
			$assoc_subjects = array('ITAL');
			break;
		case 'freshman_seminar':
			$assoc_subjects = array('ECFS');
			break;
		case 'german':
			$assoc_subjects = array('GER','YDD');
			break;
		case 'global_health':
			$assoc_subjects = array('GHCS');
			break;
		case 'physical_education_health':
			$assoc_subjects = array('PE');
			break;
		case 'history':
			$assoc_subjects = array('HIST');
			break;
		case 'institute_liberal_arts':
			$assoc_subjects = array('IDS','AMST','AFS');
			break;
		case 'irish':
			$assoc_subjects = array('ENG');
			break;
		case 'jewish':
			$assoc_subjects = array('HEBR','JS','YDD');
			break;
		case 'journalism':
			$assoc_subjects = array('JRNL');
			break;
		case 'languages':
			$assoc_subjects = array('ARAB','CHN','DUTCH','FREN','GER','GRK','HEBR','HNDI','ITAL','JPN','KRN','LING','PERS','PORT','RUSS','SPAN','TBT','YDD');
			break;
		case 'latin_american_caribbean':
			$assoc_subjects = array('LACS');
			break;
		case 'linguistics':
			$assoc_subjects = array('LING');
			break;
		case 'mathematics_computer_science':
			$assoc_subjects = array('CS','MATH');
			break;
		case 'middle_eastern_south_asian':
			$assoc_subjects = array('ARAB','ASIA','HEBR','HNDI','MESAS','PERS','SNSK', 'TBT');
			break;
		case 'music':
			$assoc_subjects = array('MUS');
			break;
		case 'neuroscience_behavioral_biology':
			$assoc_subjects = array('NBB');
			break;
		case 'philosophy':
			$assoc_subjects = array('PHIL');
			break;
		case 'physics':
			$assoc_subjects = array('PHYS');
			break;
		case 'political_science':
			$assoc_subjects = array('POLS');
			break;
		case 'premajor':
			$assoc_subjects = array('PACE');
			break;
		case 'psychology':
			$assoc_subjects = array('PSYC');
			break;
		case 'religion':
			$assoc_subjects = array('REL');
			break;
		case 'russian_east_asian':
			$assoc_subjects = array('ASIA','CHN','EAS','JPN','KRN','REALC','REES','RUSS');
			break;
		case 'sociology':
			$assoc_subjects = array('SOC');
			break;
		case 'spanish_portuguese':
			$assoc_subjects = array('PORT','SPAN','LACS');
			break;
		case 'theater_dance':
			$assoc_subjects = array('DANC','THEA');
			break;
		case 'womens':
			$assoc_subjects = array('WS');
			break;
		}
				
        return($assoc_subjects); 
	}	
	
	
?>