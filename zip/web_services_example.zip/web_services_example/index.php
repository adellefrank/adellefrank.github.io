<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
	<title>Directory Listing</title>
    
	<style type="text/css">
		h1 {
			font:Verdana, Arial, Helvetica, sans-serif;
			font-size:18px;
		}
		
		a:link, a:visited, a:active {
			color:#333333;
			text-decoration:none;
		}
		
		a:hover {
			color:#999999;
			text-decoration:underline;
		}
	
		ul {
			margin:5px 0 2px 20px;;
			padding:1px 5px;
			font:Verdana, Arial, Helvetica, sans-serif;
			font-size:14px;
		}
		
		li {
			margin:0;
			padding:0;
			font:Verdana, Arial, Helvetica, sans-serif;
			font-size:14px;
			list-style-image:url(../../images/arrow-dark.gif);
			list-style-position:inside;
		}
		
		div#directory {
			padding 10px;
			margin:15px;
	</style>
    
    
    
</head>

<body>
<div id="directory">
<?php 
	ini_set('display_errors', 1);
	ini_set('log_errors', 1);
	error_reporting(E_ALL);
?>
	
<?php

//define the path as relative
$baseDir = "/Library/WebServer/Documents/web_services_sites/";

//using the opendir function
$dir_handle = @opendir($baseDir) or die("Unable to open $baseDir");

echo "<h1>Brian's Test Site</h1>";

//running the while loop

	echo"<ul>";
		
	while ($file = readdir($dir_handle)) {
		if($file!="." && $file!="..") {
	    	echo "<li><a href='$file'>$file</a></li>";
		}
		
		if (is_dir($file)) {
			if($file!="." && $file!="..") {
				echo "<ul>";
				$dir2 = $baseDir.$file . "/";
				$dir2_handle = @opendir($dir2) or die("Unable to open $dir2");
				
				while ($file2 = readdir($dir2_handle)) {
					if($file2!="." && $file2!="..") {
					  echo "<li><a href='".$file."/".$file2."'>$file2</a></li>";
					}
					
					$dir3 = $baseDir.$file.'/'.$file2;
					
					if (is_dir($dir3)) {					
						if($file2!="." && $file2!="..") {
							echo "<ul>";
								$dir3_handle = @opendir($dir3) or die("Unable to open $dir3");
								
								while ($file3 = readdir($dir3_handle)) {
									if($file3!="." && $file3!="..") {
										echo "<li><a href='".$file."/".$file2."/".$file3."'>$file3</a></li>";
									}
								}
							echo "</ul>";
						}
					}
				}
			}
			echo "</ul>";
		} 
		
	}
	
	echo "</ul>";

//closing the directory
closedir($dir_handle);

?> 
</div>

</body>
</html>