<?php
	session_start();
?>

<?php 
	ini_set('display_errors', 1);
	ini_set('log_errors', 1);
	error_reporting(E_ERROR | E_PARSE);
	set_time_limit(0);
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
	<title>Section Get CSV Data</title>

    <link rel="stylesheet" type="text/css" href="../includes/style.css" />

</head>

<body>

<?php 
	include("../includes/headermenu.php");
	include '../includes/service.php';
	include '../includes/functions.php';
	
	if ($_REQUEST['action'] == 'create') {
		echo "<h2>Create All Atlas Course Section Pages</h2><hr />";
	} elseif($_REQUEST['action'] == 'edit') {
		echo "<h2>Edit Atlas Course Section Pages</h2><hr />";
	} else {
		echo '<h2>Create or Edit Atlas Course Section Pages</h2><hr />';
	}
		
	if ($_REQUEST['submit']) {
		if (($_REQUEST['action']) && ($_FILES['instructorsfile']) && ($_FILES['sectionsfile']) ) {
			$start_webservices = true;
		} else {
			$start_webservices = false;
			$missing = true;
		}
	}
	
	if ($start_webservices == true) {	
	
		// Process the Class Sections File
        //$sections_file = 'sections.csv'; 
		$sections_file = $_FILES['sectionsfile']['name'];
    	
		chmod($_FILES['sectionsfile']['tmp_name'],777);
		
        if(move_uploaded_file($_FILES['sectionsfile']['tmp_name'], $sections_file)) {
					
			$handle = fopen( $sections_file, "r");
			
			$row_id = 1; // row count
			
			while (($data = fgetcsv($handle, 1000, ",")) !== FALSE) {
			
				// Set Columns
				if ($data[0] == 'Career') {
					$num = count($data);             
				 
					for ($c=0; $c < $num; $c++) {
						switch ($data[$c]) {
							case "Subject":
								$subject =$c;
								break;
							case "Catalog Nbr":
								$catalog_nbr =$c;
								break;
							case "Section":
								$section =$c;
								break;
							case "Building/Room":
								$building_room =$c;
								break;
							case "Days":
								$days =$c;
								break;
							case "StartTime":
								$start_time =$c;
								break;
							case "EndTime":
								$end_time =$c;
								break;
							case "Comb Sects ID":
								$comb_sects_id =$c;
								break;
							case "Last":
								$instructor_last_name =$c;
								break;
							case "First Name":
								$instructor_first_name =$c;
								break;
							case "Instructor ID":
								$instructor_id =$c;
								break;								
						}
					}
				} else {
					// Section ID
					$data_section = '';
					if ((strlen($data[$section])) == 0) {
						$data_section = '000';
					} elseif ((strlen($data[$section])) == 1) {
						$data_section = '00' . $data[$section];
					} elseif ((strlen($data[$section])) == 2) {
						$data_section = '0' . $data[$section];
					} else {
						$data_section = $data[$section];
					}
				
					$this_system_name = $data[$subject] . $data[$catalog_nbr] . '-' . $data_section;
					
					$dtl_AR = array('days' => $data[$days], 'start_time' => $data[$start_time], 'end_time' => $data[$end_time],  'building_room' => $data[$building_room]);
					
					if ($$this_system_name) { // Array has already been created
						array_push($$this_system_name, $dtl_AR);
					} else {
						$$this_system_name = array($dtl_AR);
					} // End if
					
					
					// Set Instructors Array
					
					// Instructor ID
					$data_instructor_id = substr($data[$instructor_id], 1);
					$data_instructor_id = ltrim($data_instructor_id, '0');
					
					$this_system_name_instructors = $data[$subject] . $data[$catalog_nbr] . '-' . $data_section . '-instructors';
					
					$instruct_AR = array('last' => $data[$instructor_last_name], 'first' => $data[$instructor_first_name], 'emplid' => $data_instructor_id);
					
					if ($$this_system_name_instructors) { // Array has already been created
					
						$exists = in_array($instruct_AR, $$this_system_name_instructors);
						
						if ($exists) {
							// echo "This is a duplicate<br>";
						} else {
							array_push($$this_system_name_instructors, $instruct_AR);
						}
					} else {
						$$this_system_name_instructors = array($instruct_AR);
					} // End if
								
					// Set Crosslisted Variable
					if ($data[$comb_sects_id] != '') {
						$crosslisted_id_AR = 'CL_' . $data[$comb_sects_id];
						$this_class_section = $data[$subject] . $data[$catalog_nbr] .'-'. $data_section;
					
						if ($$crosslisted_id_AR) { // Array has already been created
							if (in_array($this_class_section, $$crosslisted_id_AR)) {
								// Already In Array
  							} else { 
								array_push($$crosslisted_id_AR, $this_class_section);
							}
						} else {
							$$crosslisted_id_AR = array($this_class_section);
						} // End if
					} // End if 
					
				
				} // End if ($data[0] == 'Subject')
				
				$row_id ++; // increment row count
				
			} // End while (($data = fgetcsv($handle, 1000, ",")) !== FALSE)
			
			fclose($handle); // Close the opened file
			
		
			
			// Process the Instructors File
			//$instructors_file = 'instructors.csv'; 
			$instructors_file = $_FILES['instructorsfile']['name'];
			
			chmod($_FILES['instructorsfile']['tmp_name'],777);
			
			if(move_uploaded_file($_FILES['instructorsfile']['tmp_name'], $instructors_file)) {
						
				$instructor_handle = fopen( $instructors_file, "r");
				
				while (($instructor_data = fgetcsv($instructor_handle, 1000, ",")) !== FALSE) {
					// Set Columns
					if ($instructor_data[0] == 'PRSN_I (Padded to 8 CHARS, EmplID)') {
						$num = count($instructor_data);             
					 
						for ($c=0; $c < $num; $c++) {
							switch ($instructor_data[$c]) {
								case "PRSN_I (Padded to 8 CHARS, EmplID)":
									$emplid = $c;
									break;
								case "PRSN_I_PBLC (Public Key ID)":
									$ppid =$c;
									break;
								case "First Name":
									$first_name =$c;
									break;
								case "Last Name":
									$last_name =$c;
									break;
							}
						}
						
					} else {
						
						$this_instructor_data = ltrim($instructor_data[$emplid], '0');
						
						$$this_instructor_data = array(
														'ppid' => $instructor_data[$ppid],
														'first_name' => $instructor_data[$first_name],
														'last_name' => $instructor_data[$last_name],
													);		
						
					} // End if ($instructor_data[0]
				
				} // End While
				
				fclose($instructor_handle);
			} // End if(move_uploaded_file
		
		
			// Set variables that doesn't need reset throught the itteration
			$year_folder_exists = '';
			$semester_folder_exists = '';
			$section_folder_exists = '';
			$session_folder_exists = '';	
			$department_folder_created = '';
		
			// Process the Class Sections File
			$handle = fopen( $sections_file, "r");
			
			while (($data = fgetcsv($handle, 1000, ",")) !== FALSE) {
			
				// Set Columns
				if ($data[0] == 'Career') {
					$num = count($data);             
				 
					for ($c=0; $c < $num; $c++) {
						switch ($data[$c]) {
							case "Career":
								$career = $c;
								break;
							case "Class Nbr":
								$class_nbr =$c;
								break;
							case "Subject":
								$subject =$c;
								break;
							case "Catalog Nbr":
								$catalog_nbr =$c;
								break;
							case "Title":
								$title =$c;
								break;
							case "Section":
								$section =$c;
								break;
							case "Topic":
								$topic =$c;
								break;
							case "Note":
								$note =$c;
								break;
							case "Min Hrs":
								$min_hrs =$c;
								break;
							case "Max Hrs":
								$max_hrs =$c;
								break;
							case "Building/Room":
								$building_room =$c;
								break;
							case "Days":
								$days =$c;
								break;
							case "StartTime":
								$start_time =$c;
								break;
							case "EndTime":
								$end_time =$c;
								break;
							case "First Name":
								$instructor_first_name =$c;
								break;
							case "Last":
								$instructor_last_name =$c;
								break;
							case "Max Enr":
								$max_enr =$c;
								break;
							case "Enr":
								$enr =$c;
								break;
							case "Grd Bse":
								$grd_bse =$c;
								break;
							case "Trm":
								$trm =$c;
								break;
							case "Class Stat":
								$class_stat =$c;
								break;
							case "Course ID":
								$course_id =$c;
								break;
							case "Designation":
								$designation =$c;
								break;
							case "Comb Sects ID":
								$comb_sects_id =$c;
								break;
							case "Descr":
								$descr =$c;
								break;
							case "Instructor ID":
								$instructor_id =$c;
								break;
							case "Session":
								$session =$c;
								break;
							case "Start Date":
								$start_date =$c;
								break;
							case "End Date":
								$end_date =$c;
								break;
						}
					}
					
				} else {
				
					if (($data[$subject] == 'AAAA') ||
						($data[$subject] == 'CIPA') || 
						($data[$subject] == 'ARCH') ||
						($data[$subject] == 'BUS')	||
						($data[$subject] == 'EAP') ||
						($data[$subject] == 'FAME') ||
						($data[$subject] == 'GENEDRQT') ||
						($data[$subject] == 'INTERN') ||
						($data[$subject] == 'NRSG') || 
						($data[$subject] == 'NS') ||
						($data[$subject] == 'OCFT')	||
						($data[$subject] == 'OTHCRD') ||
						($data[$subject] == 'RES') ||
						($data[$subject] == 'ROTC') ||	
						($data[$subject] == 'TRANSFER') ||
						($data[$subject] == 'VS') 
						) {
						// Ignore these Subject Abbreviations
					} else {       
		
						// Term Variables
							$trm_AR = str_split($data[$trm]);
							$data_section_year = '20' . $trm_AR[1] . $trm_AR[2];
							$semester = $trm_AR[3];
							
							if ($semester == '1') {
								$data_section_semester = 'spring';
								$data_section_semester_desc = 'Spring';
							} elseif ($semester == '6') {
								$data_section_semester = 'summer';
								$data_section_semester_desc = 'Summer';							
							} elseif ($semester == '9') {
								$data_section_semester = 'fall';
								$data_section_semester_desc = 'Fall';
							}
							
						// Session Variables
							if ($data[$session] == '1') {
								$data_section_session = 'regular';
							} elseif ($data[$session] == '6W1') {
								$data_section_session = '6W1';
							} elseif ($data[$session] == '6W2') {
								$data_section_session = '6W2';
							}	
						
						// Section ID
							$data_section = '';
							if ((strlen($data[$section])) == 0) {
								$data_section = '000';
							} elseif ((strlen($data[$section])) == 1) {
								$data_section = '00' . $data[$section];
							} elseif ((strlen($data[$section])) == 2) {
								$data_section = '0' . $data[$section];
							} else {
								$data_section = $data[$section];
							}
			
						// Set Combination Variables
							if ($data[$topic]) {
								$display_topic = ': ' . $data[$topic];
							} else {
								$display_topic = '';
							}
							
							if (strstr($data[$title], 'Special Topics')) {
								$display_title = 'Special Topic';
							} else {
								$display_title = $data[$title];
							} 
							
							// Get Department Folder Name
							$department_folder_name = get_department($data[$subject]);
							$department_folder_name_desc = get_department($data[$subject], 'desc'); 
						
							$data_section_display_name = $data[$subject] . ' ' . $data[$catalog_nbr] . '-' . $data_section . ': ' . $display_title . $display_topic;
							$data_section_catalog_display_name = $data[$subject] . ' ' . $data[$catalog_nbr] . ': ' . $display_title;							
							$data_section_topic_display_name = $data[$topic];
							$data_section_meta_title = $data_section_display_name . ' (' . $data_section_semester_desc . ' ' . $data_section_year . ')';
							$data_section_system_name = $data[$subject] . $data[$catalog_nbr] . '-' . $data_section;
							$data_section_parent_folder = "academic/atlas/" . $data_section_year . '/' . $data_section_semester . '/section/' . $data_section_session . '/' . $department_folder_name;
							$data_metadata_set = "class_section";
							$data_catalog_course_connection = 'academic/description/' . $department_folder_name . '/' . $data[$subject] . $data[$catalog_nbr];
							$data_syllabusFile = 'assets/documents/syllabi/' . $department_folder_name . '/example_syllabus.pdf';
							
							// Crosslisted Variables
							$data_crosslisted_id = 'CL_' . $data[$comb_sects_id];
							$data_crosslisted_AR = $$data_crosslisted_id;
							$data_crosslisted = '';
							
							foreach ($data_crosslisted_AR as $this_crosslisted) {
								if ($this_crosslisted != $data_section_system_name) {
									if ($data_crosslisted == '') {
										$data_crosslisted .= $this_crosslisted;
									} else {
										$data_crosslisted .= ', ';
										$data_crosslisted .= $this_crosslisted;
									}
								}
							} 
							
							$data_crosslisted .= '.';							
							
							// Peoplesoft Notes
							$data_peoplesoft_notes = '';
							if ($data[$note]) {
								$data_peoplesoft_notes .= $data[$note] . '.';
							}
							if ($data[$descr]) {
								$data_peoplesoft_notes .= $data[$descr] . '.';
							}
													
							$data_school = 'UndergraduateEmoryCollege';
							$data_ger_variable = 'None';
							$data_currently_offered = 'Yes';
							
							// Currently Offered
							$cancelled = strpos($data[$note], 'Cancelled');
							if ($cancelled !== false) {
								$data_currently_offered = 'No';
							} else {
								$data_currently_offered = 'Yes';
							}
							
							// GER
							if ($data[$designation] != '') { $data_ger = $data[$designation]; } else { $data_ger = 'None'; }
							
							// First year Appropriate
							if (beginsWith($data[$catalog_nbr], '1')) {
								$data_first_year = 'Yes';
							} else {
								$data_first_year = 'No';
							}
							
							// Study Abroad
							if (beginsWith($data[$section], 'S')) {
								$data_study_abroad = 'Yes';
							} else {
								$data_study_abroad = 'No';
							}
							
							// Lab
							if (beginsWith($data[$section], 'L')) {
								$data_lab = 'Yes';
							} else {
								$data_lab = 'No';
							}
										
							// Start Date	
								$start_date_AR = explode('/', $data[$start_date]);
								
								// Month
								if (strlen($start_date_AR[0]) == 0) {
									$data_start_time_month = 'None';
								} elseif (strlen($start_date_AR[0]) == 1) {
									$data_start_time_month = '0' . $start_date_AR[0];
								} else {
									$data_start_time_month = $start_date_AR[0];
								}
								
								// Day
								if (strlen($start_date_AR[1]) == 0) {
									$data_start_time_day = 'None';
								} elseif (strlen($start_date_AR[1]) == 1) {
									$data_start_time_day = '0' . $start_date_AR[1];
								} else {
									$data_start_time_day = $start_date_AR[1];
								}
								
								// Year
								if (strlen($start_date_AR[2]) == 0) {
									$data_start_time_year = 'None';
								} elseif (strlen($start_date_AR[2]) == 2) {
									$data_start_time_year = '20' . $start_date_AR[2];
								} else {
									$data_start_time_year = $start_date_AR[2];
								}								
								
							// End Date	
								$end_date_AR = explode('/', $data[$end_date]);
								
								// Month
								if (strlen($end_date_AR[0]) == 0) {
									$data_end_time_month = 'None';
								} elseif (strlen($end_date_AR[0]) == 1) {
									$data_end_time_month = '0' . $end_date_AR[0];
								} else {
									$data_end_time_month = $end_date_AR[0];
								}
								
								// Day
								if (strlen($end_date_AR[1]) == 0) {
									$data_end_time_day = 'None';
								} elseif (strlen($end_date_AR[1]) == 1) {
									$data_end_time_day = '0' . $end_date_AR[1];
								} else {
									$data_end_time_day = $end_date_AR[1];
								}
								
								// Year
								if (strlen($end_date_AR[2]) == 0) {
									$data_end_time_year = 'None';
								} elseif (strlen($end_date_AR[2]) == 2) {
									$data_end_time_year = '20' . $end_date_AR[2];
								} else {
									$data_end_time_year = $end_date_AR[2];
								}
																				
							// Times and Locations
								$dtl_i = 1;
								
								$data_start_time1 = '';
								$data_start_time_hour1 = '';
								$data_start_time_minute1 = '';
								$data_end_time_hour1 = '';
								$data_end_time_minute1 = '';
								$data_building_room1 = '';
								$data_weekdays1 = '';
								
								$data_start_time2 = '';
								$data_start_time_hour2 = '';
								$data_start_time_minute2 = '';
								$data_end_time_hour2 = '';
								$data_end_time_minute2 = '';
								$data_building_room2 = '';
								$data_weekdays2 = '';
								
								foreach ($$data_section_system_name as $thisDTL) {
								
									$data_start_time = 'data_start_time' . $dtl_i;
									$data_end_time = 'data_end_time' . $dtl_i;
									$data_weekdays = 'data_weekdays' . $dtl_i;
									$data_building_room = 'data_building_room' . $dtl_i;
									
									$$data_start_time = $thisDTL['start_time'];
									$$data_end_time = $thisDTL['end_time'];
									$$data_weekdays = $thisDTL['days'];
									$$data_building_room = $thisDTL['building_room'];
									
									$dtl_i++;
								}
													
								// Start Time 1
								if ($data_start_time1) {
									$start_time1_AR = explode('.', $data_start_time1);
									
									// Hour 1
									if (strlen($start_time1_AR[0]) == 0) {
										$data_start_time_hour1 = 'None';
									} elseif (strlen($start_time1_AR[0]) == 1) {
										$data_start_time_hour1 = '0' . $start_time1_AR[0];
									} else {
										$data_start_time_hour1 = $start_time1_AR[0];
									}
						
									// Minute 1
									if (strlen($start_time1_AR[1]) == 0) {
										$data_start_time_minute1 = '00';
									} elseif (strlen($start_time1_AR[1]) == 1) {
										$data_start_time_minute1 = $start_time1_AR[1] . '0';
									} else {
										$data_start_time_minute1 = $start_time1_AR[1];
									}
																	
								// End Time 1
									$end_time1_AR = explode('.', $data_end_time1);
								
									// Hour 2
									if (strlen($end_time1_AR[0]) == 0) {
										$data_end_time_hour1 = 'None';
									} elseif (strlen($end_time1_AR[0]) == 1) {
										$data_end_time_hour1 = '0' . $end_time1_AR[0];
									} else {
										$data_end_time_hour1 = $end_time1_AR[0];
									}
									
									// Minute 1
									if (strlen($end_time1_AR[1]) == 0) {
										$data_end_time_minute1 = '00';
									} elseif (strlen($end_time1_AR[1]) == 1) {
										$data_end_time_minute1 = $end_time1_AR[1] . '0';
									} else {
										$data_end_time_minute1 = $end_time1_AR[1];
									}
								} else {
									$data_start_time_hour1 = 'None';
									$data_start_time_minute1 = 'None';
									$data_end_time_hour1 = 'None';
									$data_end_time_minute1 = 'None';
								} // End if
									
								// Start Time 2
								if ($data_start_time2) {
									$start_time2_AR = explode('.', $data_start_time2);
									
									// Hour 2
									if (strlen($start_time2_AR[0]) == 0) {
										$data_start_time_hour2 = 'None';
									} elseif (strlen($start_time2_AR[0]) == 1) {
										$data_start_time_hour2 = '0' . $start_time2_AR[0];
									} else {
										$data_start_time_hour2 = $start_time2_AR[0];
									}
									
									// Minute 2
									if (strlen($start_time2_AR[1]) == 0) {
										if ($data_start_time_hour2 == 'None') {
											$data_start_time_minute2 = 'None';
										} else {
											$data_start_time_minute2 = '00';
										}
									} elseif (strlen($start_time2_AR[1]) == 1) {
										$data_start_time_minute2 = $start_time2_AR[1] . '0';
									} else {
										$data_start_time_minute2 = $start_time2_AR[1];
									}
								
								// End Time 2
									$end_time2_AR = explode('.', $data_end_time2);
								
									// Hour 2
									if (strlen($end_time2_AR[0]) == 0) {
										$data_end_time_hour2 = 'None';
									} elseif (strlen($end_time2_AR[0]) == 1) {
										$data_end_time_hour2 = '0' . $end_time2_AR[0];
									} else {
										$data_end_time_hour2 = $end_time2_AR[0];
									}
									
									// Minute 2
									if (strlen($end_time2_AR[1]) == 0) {
										if ($data_end_time_hour2 == 'None') {
											$data_end_time_minute2 = 'None';
										} else {
											$data_end_time_minute2 = '00';
										}
									} elseif (strlen($end_time2_AR[1]) == 1) {
										$data_end_time_minute2 = $end_time2_AR[1] . '0';
									} else {
										$data_end_time_minute2 = $end_time2_AR[1];
									}
								} else {
									$data_start_time_hour2 = 'None';
									$data_start_time_minute2 = 'None';
									$data_end_time_hour2 = 'None';
									$data_end_time_minute2 = 'None';
								} // End if
								
								// Same Location
								if ($data_building_room1 == $data_building_room2) {
									// Same Days of the Week
									if ($data_weekdays1 == $data_weekdays2) {
										// Same Start Hours
										if ($data_start_time_hour1 == $data_start_time_hour2) {
											// Same Start Minute
											if ($data_start_time_minute1 == $data_start_time_minute2) {
												// Same End Hours
												if ($data_end_time_hour1 == $data_end_time_hour2) {
													// Same End Minutes
													if ($data_end_time_minute1 == $data_end_time_minute2) {
														// Clear the Second Set
														$data_building_room2 = '';
														$data_weekdays2 = 'None';
														$data_start_time_hour2 = 'None';
														$data_start_time_minute2 = 'None';
														$data_end_time_hour2 = 'None';
														$data_end_time_minute2 = 'None';
													}
												}
											}
										}
									}
								}
							
								//echo $data_section_system_name . "<br>";
								//echo "Start Time Hour1: " . $data_start_time_hour1 . "<br>";
								//echo "Start Time Minute1: " . $data_start_time_minute1 . "<br>";								
								//echo "Start Time Hour2: " . $data_start_time_hour2 . "<br>";
								//echo "Start Time Minute2: " . $data_start_time_minute2 . "<br>";
							
						// Include Specific Web Services Actions
						if ($_REQUEST['action'] == 'create') {
							// Add Session Data
							$add_page_path = $data_section_parent_folder .'/'. $data_section_system_name;
							
							$path = array('path' => $add_page_path, 'siteName' => 'College');
							$id = array('path' => $path, 'type' => 'page');
							$readParams = array( 'authentication' => $auth, 'identifier' => $id );				
						
							$pageRead = $service->read($readParams);
							
							if ( $pageRead->readReturn->success != 'true' ) {
																					
								// Check to see if all the folders exist
									$year_parent_folder = 'academic/atlas';
									$year_folder = $year_parent_folder . '/' . $data_section_year;
									$semester_parent_folder = $year_folder;
									$semester_folder = $semester_parent_folder . '/' . $data_section_semester;
									$section_parent_folder = $semester_folder;
									$section_folder = $section_parent_folder . '/section';
									$session_parent_folder = $section_folder;
									$session_folder = $session_parent_folder . '/' . $data_section_session;
									$department_parent_folder = $session_folder;
									$department_folder = $department_parent_folder . '/' . $department_folder_name;
									
									// Set variables for changing folders and indexes
									$department_folder_exists = '';
									$session_department_name = $data_section_session .'/'. $department_folder_name;
								
									// Year Folder
									if ($year_folder_exists == '') {
										$path = array('path' => $year_folder, 'siteName' => 'College');
										$id = array('path' => $path, 'type' => 'folder');
										$readParams = array( 'authentication' => $auth, 'identifier' => $id );				
										
										$folderRead = $service->read($readParams);
													
										if ( $folderRead->readReturn->success != 'true' ) {
											$folderAsset = array( 
												'folder' => array (
													'shouldBePublished' => true,
													'shouldBeIndexed' => true,
													'parentFolderPath' => $year_parent_folder,
													'name' => $data_section_year,
													'siteName' => 'College',
													'metadataSetPath' => 'Default',
													'metadata' => array(
														'author' => 'Web Services',
														'displayName' => $data_section_year,
														'title' => $data_section_year
													)
												)
											);
											
											$createParams = array( 'authentication' => $auth, 'asset' => $folderAsset );	
											$folderCreate = $service->create($createParams);
											
											if ( $folderCreate->createReturn->success == 'true' ) {
												echo "<h1>Created ". $data_section_year ." Folder.</h1>";
												$year_folder_exists = true;
												
											} // End if
										} else {
											$year_folder_exists = true;	
										}// End if
									} // End if
									// End Year Folder
									
									// Semester Folder
									if ($semester_folder_exists == '') {
										if ($year_folder_exists) {
											$path = array('path' => $semester_folder, 'siteName' => 'College');
											$id = array('path' => $path, 'type' => 'folder');
											$readParams = array( 'authentication' => $auth, 'identifier' => $id );				
											
											$folderRead = $service->read($readParams);
														
											if ( $folderRead->readReturn->success != 'true' ) {
												$folderAsset = array( 
													'folder' => array (
														'shouldBePublished' => true,
														'shouldBeIndexed' => true,
														'parentFolderPath' => $semester_parent_folder,
														'name' => $data_section_semester,
														'siteName' => 'College',
														'metadataSetPath' => 'Default',
														'metadata' => array(
															'author' => 'Web Services',
															'displayName' => $data_section_semester,
															'title' => $data_section_semester
														)
													)
												);
												
												$createParams = array( 'authentication' => $auth, 'asset' => $folderAsset );	
												$folderCreate = $service->create($createParams);
												
												if ( $folderCreate->createReturn->success == 'true' ) {
													echo "<h1>Created ". $data_section_semester ." Folder.</h1>";
													$semester_folder_exists = true;
													
												} // End if
											} else {
												$semester_folder_exists = true;	
											}// End if
										} // End if 
									} // End if
									// End Semester Folder
																	
									// Section Folder
									if ($section_folder_exists == '') {
										if ($semester_folder_exists) {
											$path = array('path' => $section_folder, 'siteName' => 'College');
											$id = array('path' => $path, 'type' => 'folder');
											$readParams = array( 'authentication' => $auth, 'identifier' => $id );				
											
											$folderRead = $service->read($readParams);
														
											if ( $folderRead->readReturn->success != 'true' ) {
												$folderAsset = array( 
													'folder' => array (
														'shouldBePublished' => true,
														'shouldBeIndexed' => true,
														'parentFolderPath' => $section_parent_folder,
														'name' => 'section',
														'siteName' => 'College',
														'metadataSetPath' => 'Default',
														'metadata' => array(
															'author' => 'Web Services',
															'displayName' => 'section',
															'title' => 'section'
														)
													)
												);
												
												$createParams = array( 'authentication' => $auth, 'asset' => $folderAsset );	
												$folderCreate = $service->create($createParams);
												
												if ( $folderCreate->createReturn->success == 'true' ) {
													echo "<h1>Created section Folder.</h1>";
													$section_folder_exists = true;
												
												}// End if
											} else {
												$section_folder_exists = true;
											} // End if
										} // End if 
									} // End if
									// End Section Folder
									
									// Session Folder
									if ($session_folder_exists == '') {
										if ($section_folder_exists) {
											if ($data_section_semester == 'summer') {
																								
												// regular folder
												$session_folder = $session_parent_folder . '/regular';
												$path = array('path' => $session_folder, 'siteName' => 'College');
												$id = array('path' => $path, 'type' => 'folder');
												$readParams = array( 'authentication' => $auth, 'identifier' => $id );				
												
												$folderRead = $service->read($readParams);
															
												if ( $folderRead->readReturn->success != 'true' ) {
													$folderAsset = array( 
														'folder' => array (
															'shouldBePublished' => true,
															'shouldBeIndexed' => true,
															'parentFolderPath' => $session_parent_folder,
															'name' => 'regular',
															'siteName' => 'College',
															'metadataSetPath' => 'Default',
															'metadata' => array(
																'author' => 'Web Services',
																'displayName' => 'Regular Session',
																'title' => 'regular'
															)
														)
													);
													
													$createParams = array( 'authentication' => $auth, 'asset' => $folderAsset );	
													$folderCreate = $service->create($createParams);
													
													if ( $folderCreate->createReturn->success == 'true' ) {
														echo "<h1>Created regular Folder.</h1>";
													} // End if
													
												} // End if
													
												// 6W1 folder
												$session_folder = $session_parent_folder . '/6W1';
												$path = array('path' => $session_folder, 'siteName' => 'College');
												$id = array('path' => $path, 'type' => 'folder');
												$readParams = array( 'authentication' => $auth, 'identifier' => $id );				
												
												$folderRead = $service->read($readParams);
															
												if ( $folderRead->readReturn->success != 'true' ) {
													$folderAsset = array( 
														'folder' => array (
															'shouldBePublished' => true,
															'shouldBeIndexed' => true,
															'parentFolderPath' => $session_parent_folder,
															'name' => '6W1',
															'siteName' => 'College',
															'metadataSetPath' => 'Default',
															'metadata' => array(
																'author' => 'Web Services',
																'displayName' => '6W1 Session',
																'title' => '6W1'
															)
														)
													);
													
													$createParams = array( 'authentication' => $auth, 'asset' => $folderAsset );	
													$folderCreate = $service->create($createParams);
													
													if ( $folderCreate->createReturn->success == 'true' ) {
														echo "<h1>Created 6W1 Folder.</h1>";
													} // End if
													
												} // End if
													
												// 6W2 folder
												$session_folder = $session_parent_folder . '/6W2';
												$path = array('path' => $session_folder, 'siteName' => 'College');
												$id = array('path' => $path, 'type' => 'folder');
												$readParams = array( 'authentication' => $auth, 'identifier' => $id );				
												
												$folderRead = $service->read($readParams);
															
												if ( $folderRead->readReturn->success != 'true' ) {
													$folderAsset = array( 
														'folder' => array (
															'shouldBePublished' => true,
															'shouldBeIndexed' => true,
															'parentFolderPath' => $session_parent_folder,
															'name' => '6W2',
															'siteName' => 'College',
															'metadataSetPath' => 'Default',
															'metadata' => array(
																'author' => 'Web Services',
																'displayName' => '6W2 Session',
																'title' => '6W2'
															)
														)
													);
													
													$createParams = array( 'authentication' => $auth, 'asset' => $folderAsset );	
													$folderCreate = $service->create($createParams);
													
													if ( $folderCreate->createReturn->success == 'true' ) {
														echo "<h1>Created 6W2 Folder.</h1>";
													} // End if
												} // End if
												
												$session_folder_exists = true;
												
											} else {
												$path = array('path' => $session_folder, 'siteName' => 'College');
												$id = array('path' => $path, 'type' => 'folder');
												$readParams = array( 'authentication' => $auth, 'identifier' => $id );				
												
												$folderRead = $service->read($readParams);
															
												if ( $folderRead->readReturn->success != 'true' ) {
													$folderAsset = array( 
														'folder' => array (
															'shouldBePublished' => true,
															'shouldBeIndexed' => true,
															'parentFolderPath' => $session_parent_folder,
															'name' => $data_section_session,
															'siteName' => 'College',
															'metadataSetPath' => 'Default',
															'metadata' => array(
																'author' => 'Web Services',
																'displayName' => $data_section_session,
																'title' => $data_section_session
															)
														)
													);
													
													$createParams = array( 'authentication' => $auth, 'asset' => $folderAsset );	
													$folderCreate = $service->create($createParams);
													
													if ( $folderCreate->createReturn->success == 'true' ) {
														echo "<h1>Created ". $data_section_session ." Folder.</h1>";
														$session_folder_exists = true;
														$session_folder_created = $data_section_session;
														
													} // End if
												} else {
													$session_folder_exists = true;
												}// End if
											} // End if
										} // End if
									} // End if
									// End Session Folder
																	
									// Department Folder
									if ($session_department_name != $department_folder_created) {
										if ($session_folder_exists) {
											$path = array('path' => $department_folder, 'siteName' => 'College');
											$id = array('path' => $path, 'type' => 'folder');
											$readParams = array( 'authentication' => $auth, 'identifier' => $id );				
											
											$folderRead = $service->read($readParams);
														
											if ( $folderRead->readReturn->success != 'true' ) {
												$folderAsset = array( 
													'folder' => array (
														'shouldBePublished' => true,
														'shouldBeIndexed' => true,
														'parentFolderPath' => $department_parent_folder,
														'name' => $department_folder_name,
														'siteName' => 'College',
														'metadataSetPath' => 'Default',
														'metadata' => array(
															'author' => 'Web Services',
															'displayName' => $department_folder_name_desc,
															'title' => $department_folder_name_desc
														)
													)
												);
												
												$createParams = array( 'authentication' => $auth, 'asset' => $folderAsset );	
												$folderCreate = $service->create($createParams);
												
												if ( $folderCreate->createReturn->success == 'true' ) {
													echo "<h1>Created ". $session_department_name ." Folder.</h1>";
													$department_folder_created = $session_department_name;
												} // End if
											}
										} else {
											echo "we have a problem with the session folder";
										} // End if 
									} // End if
									// Department Folder
										
								// End Folder Check
								
								// Add the class section
//////////////// ADD ////////////////									
								include ('add_section.php');
								
							} else {
								echo "<h1>". $data_section_system_name ." exists.</h1>";
							}
								
						} elseif ($_REQUEST['action'] == 'edit') {
							// Edit Course Data
//////////////// EDIT ////////////////						
							include ('edit_class_sections.php');	
							echo "<hr>";
						}
	
						// Display different stuff depending on action
						if ($_REQUEST['action'] == 'create') {
							echo $listing;
						} elseif ($_REQUEST['action'] == 'edit') { 						
							if ($crosslisted_courses_AR) {
								echo $listing;
							}			
						}
						
					} // End if (($data[$subject] ==
					
				} // End if ($data[0] == 'Subject')
				
				// sleep for 10 seconds
				sleep(0);
				
			} // End while (($data = fgetcsv($handle, 1000, ",")) !== FALSE)
			
			fclose($handle); // Close the opened file
			unlink($sections_file); // Delete the Class Sections file
			unlink($instructors_file); // Delete the instructors file
			
			// Set Session Variable Completed
			if ($semester == '6') {
				$_SESSION['summer_create_all_class_sections'] = true;
			} else {
				$_SESSION['fall_create_all_class_sections'] = true;
			}
			
		} else {
			echo "<h1>There is a problem with the file you uploaded.</h1>";
		} // End if(move_uploaded_file
					
	} else {
?>
        
		<form enctype="multipart/form-data" action="<?php echo $PHP_SELF;?>" method="post" name="create_edit" target="_self">
			<div class="information">
<?php
					if ($missing) {
?>				
						<p style="color:red;">You must fill out all fields below.</p>
<?php
					}
?>
                <p>
                	<input type="hidden" name="MAX_FILE_SIZE" value="1000000000000000" />
					Choose the <strong>class sections</strong> file to upload: <input name="sectionsfile" type="file" />
                </p>
                
                <p>
                	<input type="hidden" name="MAX_FILE_SIZE" value="1000000000000000" />
					Choose the <strong>instructor lookup table</strong> file: <input name="instructorsfile" type="file" />
                </p>
                
                <p>
                    Do you want to 
                    <input name="action" type="radio" value="create"/>CREATE 
                    or 
                    <input name="action" type="radio" value="edit" />EDIT
                    Sections with Web Services? 
                </p>
                
                <p>
                    <input name="submit" type="submit" value="Start Web Services" />
                </p>
            </div>
		</form>
<?php
	} // End if ($start_webservices == true)
?>
</body>
</html>