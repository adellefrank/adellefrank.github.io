<?php	
	$log = '';
	// Choose subnav block
	if ($semester == '6') {
		$subnav_block = '_internal/blocks/static/atlas/block_subnav_atlas_class_section_summer';
	} else {
		$subnav_block = '_internal/blocks/static/atlas/block_subnav_atlas_class_section_fall_spring';
	}
	
	
	// Create Weekdays 1 Array
	$weekdays1_AR = str_split($data_weekdays1);
	
	$data_weekdays1_AR = array();
	
	foreach($weekdays1_AR  as $this_weekday1) {
		if ($this_weekday1 != ' ') {
			switch ($this_weekday1) {
				case 'M':
					$this_weekday1_value = 1;
					break;
				case 'T':
					$this_weekday1_value = 2;
					break;
				case 'W':
					$this_weekday1_value = 3;
					break;
				case 'R':
					$this_weekday1_value = 4;
					break;
				case 'F':
					$this_weekday1_value = 5;
					break;
				case 'Sa':
					$this_weekday1_value = 6;
					break;
				case 'Su':
					$this_weekday1_value = 7;
					break;
				default:
					$this_weekday1_value = 'None';
			}
			
			$this_weekday1_AR = array ('value' => $this_weekday1_value);
			array_push($data_weekdays1_AR, $this_weekday1_AR);
		}
	}	
	
	// Create Weekdays 2 Array
	$weekdays2_AR = str_split($data_weekdays2);
	
	$data_weekdays2_AR = array();
	
	foreach($weekdays2_AR  as $this_weekday2) {
		if ($this_weekday2 != ' ') {
			switch ($this_weekday2) {
				case 'M':
					$this_weekday2_value = 1;
					break;
				case 'T':
					$this_weekday2_value = 2;
					break;
				case 'W':
					$this_weekday2_value = 3;
					break;
				case 'R':
					$this_weekday2_value = 4;
					break;
				case 'F':
					$this_weekday2_value = 5;
					break;
				case 'Sa':
					$this_weekday2_value = 6;
					break;
				case 'Su':
					$this_weekday2_value = 7;
					break;
				default:
					$this_weekday2_value = 'None';
			}
			
			$this_weekday2_AR = array ('value' => $this_weekday2_value);
			array_push($data_weekdays2_AR, $this_weekday2_AR);
		}
	}	
	
	// Instructor
	$data_instructor_AR = array();
	$entire_instructors_AR = $data_section_system_name . '-instructors';
	$metadata_instructors_display_name = '';
	
	foreach ($$entire_instructors_AR as $thisInstructor) {

		$this_first = $thisInstructor['first'];
		$this_last = $thisInstructor['last'];
		$this_emplid = $thisInstructor['emplid'];
		
		if ($this_last == '') {
			$metadata_instructors_display_name = '';
			$data_instructors_ppid = '';
			$data_instructor_name = '';
			$data_person_instructor_asset_path = '';
		} else {
			$metadata_instructors_display_name .= $this_last . '; ';
			
			$data_instructor_name = '';
		
			// Instructor Display Name
			if ($this_last) {
				$data_instructor_name = $this_last;
			} 
		
			if ($this_first) {
				$data_instructor_name .= ', ' . $this_first;
			}
			
			// Instructor Person Asset
			$data_person_instructor_asset = '';
			$data_person_instructor_asset_path = '';
			$data_instructors_ppid = '';
			$add_instructor_to_array = false;
			
			if (($this_emplid != '') && ($this_emplid != 'P')) { // Blank Instructor
				if ($$this_emplid) { // Instructor found in lookup table

					$data_instructor_id_AR = $$this_emplid;
					
					$data_person_instructor_asset = $data_instructor_id_AR['last_name'] .'_'. $data_instructor_id_AR['first_name'] .'_'. $data_instructor_id_AR['ppid'];
						// Removes Spaces 
						$data_person_instructor_asset = str_replace(" ", "_", $data_person_instructor_asset);
						// Removes periods
						$data_person_instructor_asset = str_replace(".", "", $data_person_instructor_asset);
						// Removes apostrophes
						$data_person_instructor_asset = str_replace("'", "", $data_person_instructor_asset);
					$data_person_instructor_asset_path = 'about/people/faculty/' . $data_person_instructor_asset;
					
					$data_instructors_ppid = $data_instructor_id_AR['ppid'];
					
					$add_instructor_to_array = true;
				} // End if
			} // End if		
		}// End if

		// Create the Instructor Array
		$this_instructor_AR = array (
			'type' => 'group',
			'identifier' => 'Instructor',
			'structuredDataNodes' => array (										
				'structuredDataNode' => array (
					// Instructors PPID
					array (
						'type' => 'text',
						'identifier' => 'EmployeeId',
						'text' => $data_instructors_ppid
					),
					
					// Formatted Name
					array (
						'type' => 'text',
						'identifier' => 'FormattedName',
						'text' => $data_instructor_name
					),
					
					// Bio Page
					array (
						'type' => 'asset',
						'identifier' => 'PersonInstructor',
						'assetType' => 'page',
						'pagePath' => $data_person_instructor_asset_path
					),
				)
			)
		);
		array_push($data_instructor_AR, $this_instructor_AR);
	} // End foreach	
	
	// Set Page Asset Information
	$asset = array( 
		'page' => array (
			'shouldBePublished' => true,
			'shouldBeIndexed' => true,
			'contentTypePath' => 'class_section',
			'parentFolderPath' => $data_section_parent_folder,
			'metadataSetPath' => 'class_section',
			'name' => $data_section_system_name,
			'siteName' => 'College',
			'metadata' => array(
				'author' => 'Web Services',
				'displayName' => $data_section_display_name,
				'title' => $data_section_meta_title,
				'dynamicFields' => array (
					'dynamicField' => array (
						// Metadata - Catalog Display Name
						array (
							'name' => 'catalog_display_name',
							'fieldValues' => array (
								'fieldValue' => array (
									'value' => $data_section_catalog_display_name
								)
							)
						),
						// Metadata - Topic Display name
						array (
							'name' => 'topic_display_name',
							'fieldValues' => array (
								'fieldValue' => array (
									'value' => $data_section_topic_display_name
								)
							)
						),
						// Metadata - Session
						array (
							'name' => 'Session',
							'fieldValues' => array (
								'fieldValue' => array (
									'value' => $data[$session]
								)
							)
						),
						// Metadata - Term
						array (
							'name' => 'Term',
							'fieldValues' => array (
								'fieldValue' => array (
									'value' => $data[$trm]
								)
							)
						),
						// Metadata - GER
						array (
							'name' => 'GER',
							'fieldValues' => array (
								'fieldValue' => array (
									'value' => $data_ger
								)
							)
						),
						// Metadata - GER Variable
						array (
							'name' => 'GER_variable',
							'fieldValues' => array (
								'fieldValue' => array (
									'value' => $data_ger_variable
								)
							)
						),
						// Metadata - Instructors Display Name 
						array (
							'name' => 'instructors_display_name',
							'fieldValues' => array (
								'fieldValue' => array (
									'value' => $metadata_instructors_display_name
								)
							)
						),
						// Metadata - Study Abroad
						array (
							'name' => 'StudyAbroad',
							'fieldValues' => array (
								'fieldValue' => array (
									'value' => $data_study_abroad
								)
							)
						),
						// Metadata - Lab
						array (
							'name' => 'Lab',
							'fieldValues' => array (
								'fieldValue' => array (
									'value' => $data_lab
								)
							)
						),
						// Metadata - First Year Appropriate
						array (
							'name' => 'FirstYearAudience',
							'fieldValues' => array (
								'fieldValue' => array (
									'value' => $data_first_year
								)
							)
						),
						// Metadata - Status
						array (
							'name' => 'Status',
							'fieldValues' => array (
								'fieldValue' => array (
									'value' => $data_currently_offered
								)
							)
						),
						// Metadata - Start Year
						array (
							'name' => 'StartTimeYear',
							'fieldValues' => array (
								'fieldValue' => array (
									'value' => $data_start_time_year
								)
							)
						),
						// Metadata - Start Month
						array (
							'name' => 'StartTimeMonth',
							'fieldValues' => array (
								'fieldValue' => array (
									'value' => $data_start_time_month
								)
							)
						),
						// Metadata - Start Day
						array (
							'name' => 'StartTimeDay',
							'fieldValues' => array (
								'fieldValue' => array (
									'value' => $data_start_time_day
								)
							)
						),
						// Metadata - End Year
						array (
							'name' => 'EndTimeYear',
							'fieldValues' => array (
								'fieldValue' => array (
									'value' => $data_end_time_year
								)
							)
						),
						// Metadata - End Month
						array (
							'name' => 'EndTimeMonth',
							'fieldValues' => array (
								'fieldValue' => array (
									'value' => $data_end_time_month
								)
							)
						),
						// Metadata - End Day
						array (
							'name' => 'EndTimeDay',
							'fieldValues' => array (
								'fieldValue' => array (
									'value' => $data_end_time_day
								)
							)
						),
						
						// First Set of Days & Time
						// Metadata - Weekdays1
						array (
							'name' => 'Weekdays1',
							'fieldValues' => array (
								'fieldValue' => $data_weekdays1_AR
							)
						),
						// Metadata - Start Hour1
						array (
							'name' => 'StartTimeHour1',
							'fieldValues' => array (
								'fieldValue' => array (
									'value' => $data_start_time_hour1
								)
							)
						),
						// Metadata - Start Minute1
						array (
							'name' => 'StartTimeMinute1',
							'fieldValues' => array (
								'fieldValue' => array (
									'value' => $data_start_time_minute1
								)
							)
						),
						// Metadata - End Hour1
						array (
							'name' => 'EndTimeHour1',
							'fieldValues' => array (
								'fieldValue' => array (
									'value' => $data_end_time_hour1
								)
							)
						),
						// Metadata - End Minute1
						array (
							'name' => 'EndTimeMinute1',
							'fieldValues' => array (
								'fieldValue' => array (
									'value' => $data_end_time_minute1
								)
							)
						),
						
						// Second Set of Days & Time
						// Metadata - Weekdays2
						array (
							'name' => 'Weekdays2',
							'fieldValues' => array (
								'fieldValue' => $data_weekdays2_AR
							)
						),
						// Metadata - Start Hour2
						array (
							'name' => 'StartTimeHour2',
							'fieldValues' => array (
								'fieldValue' => array (
									'value' => $data_start_time_hour2
								)
							)
						),
						// Metadata - Start Minute2
						array (
							'name' => 'StartTimeMinute2',
							'fieldValues' => array (
								'fieldValue' => array (
									'value' => $data_start_time_minute2
								)
							)
						),
						// Metadata - End Hour2
						array (
							'name' => 'EndTimeHour2',
							'fieldValues' => array (
								'fieldValue' => array (
									'value' => $data_end_time_hour2
								)
							)
						),
						// Metadata - End Minute2
						array (
							'name' => 'EndTimeMinute2',
							'fieldValues' => array (
								'fieldValue' => array (
									'value' => $data_end_time_minute2
								)
							)
						),
												
						// Metadata - School
						array (
							'name' => 'School',
							'fieldValues' => array (
								'fieldValue' => array (
									'value' => $data_school
								)
							)
						),	
					)
				)
			),
			
			'pageConfigurations' => array (
				'pageConfiguration' => array (
					'name' => 'HTML',
					'defaultConfiguration' => true,
					'templatePath' => '/_internal/templates/college_secondary', 
					'pageRegions' => array (
						'pageRegion' => array (
							'name' => 'SUBNAV',
							'blockPath' => $subnav_block,
						),
					),
				),
			),
			
			'structuredData' => array (
				'definitionPath' => 'class_section',
				'structuredDataNodes' => array (													
					'structuredDataNode' => array (
						
						// PeopleSoftCodes Group
						array (
							'type' => 'group',
							'identifier' => 'PeopleSoftCodes',
							'structuredDataNodes' => array (										
								'structuredDataNode' => array (
									// Course ID
									array (
										'type' => 'text',
										'identifier' => 'CourseID',
										'text' => $data[$course_id]
									),
									
									// Crosslisting ID
									array (
										'type' => 'text',
										'identifier' => 'CrosslistingID',
										'text' => $data[$comb_sects_id]
									),
							
									// Class ID
									array (
										'type' => 'text',
										'identifier' => 'ClassID',
										'text' => $data[$class_nbr] 
									),
									
									// Catalog Number
									array (
										'type' => 'text',
										'identifier' => 'NoteMessagePeoplesoft',
										'text' => $data_peoplesoft_notes
									),
									
									// PermissionRequired
									array (
										'type' => 'text',
										'identifier' => 'PermissionRequired',
										'text' => 'None'
									),
									
									// Grading Option
									array (
										'type' => 'text',
										'identifier' => 'CreditGradingOption',
										'text' => $data[$grd_bse]
									)
								)								
							) 
						), //End PeopleSoftCodes Group
						
						// Catalog Course Connection
						array (
							'type' => 'asset',
							'identifier' => 'CatalogInfo',
							'assetType' => 'page',
							'pagePath' => $data_catalog_course_connection
						), // End Catalog Course Connection
						
						// Number Group
						array (
							'type' => 'group',
							'identifier' => 'Number',
							'structuredDataNodes' => array (										
								'structuredDataNode' => array (
									// Subject
									array (
										'type' => 'text',
										'identifier' => 'SubjectAbbreviation',
										'text' => $data[$subject]
									),
									
									// Catalog Number
									array (
										'type' => 'text',
										'identifier' => 'CatalogNumber',
										'text' => $data[$catalog_nbr]
									),
									
									// Section Number
									array (
										'type' => 'text',
										'identifier' => 'CatalogNumberExtension',
										'text' => $data_section
									),
								)
							)
						), // End Number Group
						
						// Title Group
						array (
							'type' => 'group',
							'identifier' => 'Title',
							'structuredDataNodes' => array (										
								'structuredDataNode' => array (
									// Short Title
									array (
										'type' => 'text',
										'identifier' => 'ShortTitle',
										'text' => $data[$title]
									),
									
									// Long Title 
									array (
										'type' => 'text',
										'identifier' => 'LongTitle',
										'text' => $data[$topic]
									),
									
									// Short Title Text
									array (
										'type' => 'text',
										'identifier' => 'ShortTitleText',
										'text' => $data[$title]
									),
								)
							)
						),
						// End Title Group
												
						// Intstructors Group
						array (
							'type' => 'group',
							'identifier' => 'Instructors',
							'structuredDataNodes' => array (										
								'structuredDataNode' => $data_instructor_AR
							)
						), // End Instructors Group
						
						// Location Group
						array (
							'type' => 'group',
							'identifier' => 'InstructionSite',
							'structuredDataNodes' => array (										
								'structuredDataNode' => array (
									// Building and Room 1
									array (
										'type' => 'text',
										'identifier' => 'InstructionSitePeoplesoft1',
										'text' => $data_building_room1
									),
									
									// Building and Room 2
									array (
										'type' => 'text',
										'identifier' => 'InstructionSitePeoplesoft2',
										'text' => $data_building_room2
									),
								)
							)
						), // End Location Group
						
						// Credits Group
						array (
							'type' => 'group',
							'identifier' => 'Credits',
							'structuredDataNodes' => array (										
								'structuredDataNode' => array (
									// Minimum Credits
									array (
										'type' => 'text',
										'identifier' => 'CreditMinimumValue',
										'text' => $data[$min_hrs]
									),
									
									// Maximum Credits
									array (
										'type' => 'text',
										'identifier' => 'CreditMaximumValue',
										'text' => $data[$max_hrs]
									),
								)
							)
						), // End Credits Group
						
						// Details Group
						array (
							'type' => 'group',
							'identifier' => 'InstructorNotes',
							'structuredDataNodes' => array (										
								'structuredDataNode' => array (
									// NoteMessageInstructor
									array (
										'type' => 'text',
										'identifier' => 'NoteMessageInstructor',
										'text' => ''
									),
									
									// SyllabusFile
									array (
										'type' => 'asset',
										'identifier' => 'SyllabusFile',
										'assetType' => 'file',
										'filePath' => $data_syllabusFile
									),
									
									// InternetWebAddress
									array (
										'type' => 'text',
										'identifier' => 'InternetWebAddress',
										'text' => ''
									),
									
									// Resources Group
									array (
										'type' => 'group',
										'identifier' => 'Resources',
										'structuredDataNodes' => array (
											'structuredDataNode' => array (
												// Required Group
												array (
													'type' => 'group',
													'identifier' => 'Required',
													'structuredDataNodes' => array (
														'structuredDataNode' => array (
															// Required Resource Group
															array (
																'type' => 'group',
																'identifier' => 'RequiredResource',
																'structuredDataNodes' => array (
																	'structuredDataNode' => array (
																		// ResourceType
																		array (
																			'type' => 'text',
																			'identifier' => 'ResourceType',
																			'text' => 'Book'
																		),
																		
																		// StandardNumberType
																		array (
																			'type' => 'text',
																			'identifier' => 'StandardNumberType',
																			'text' => 'ISBN'
																		),
																		
																		// StandardNumber
																		array (
																			'type' => 'text',
																			'identifier' => 'StandardNumber',
																			'text' => ''
																		),
																		
																		// Title
																		array (
																			'type' => 'text',
																			'identifier' => 'Title',
																			'text' => ''
																		),
																		
																		// AuthorGivenName
																		array (
																			'type' => 'text',
																			'identifier' => 'AuthorGivenName',
																			'text' => ''
																		),
																		
																		// AuthorFamily
																		array (
																			'type' => 'text',
																			'identifier' => 'AuthorFamily',
																			'text' => ''
																		),
																		
																		// PublicationYear
																		array (
																			'type' => 'text',
																			'identifier' => 'PublicationYear',
																			'text' => '1900'
																		),
																		
																		// Cost
																		array (
																			'type' => 'text',
																			'identifier' => 'Cost',
																			'text' => ''
																		),
																		
																		// JournalTitle
																		array (
																			'type' => 'text',
																			'identifier' => 'JournalTitle',
																			'text' => ''
																		),
																		
																		// JournalLink
																		array (
																			'type' => 'text',
																			'identifier' => 'JournalLink',
																			'text' => ''
																		),
																		
																		// InternetWebAddress
																		array (
																			'type' => 'text',
																			'identifier' => 'InternetWebAddress',
																			'text' => ''
																		),
																		
																		// Description
																		array (
																			'type' => 'text',
																			'identifier' => 'Description',
																			'text' => ''
																		),
																			   
																	)							   
																)
															), // End Required Resource Group
														)
													)
												), // End Required Group
												
												// Recommended Group
												array (
													'type' => 'group',
													'identifier' => 'Recommended',
													'structuredDataNodes' => array (
														'structuredDataNode' => array (
															// Recommended Resource Group
															array (
																'type' => 'group',
																'identifier' => 'RecommendedResource',
																'structuredDataNodes' => array (
																	'structuredDataNode' => array (
																		// ResourceType
																		array (
																			'type' => 'text',
																			'identifier' => 'ResourceType',
																			'text' => 'Book'
																		),
																		
																		// StandardNumberType
																		array (
																			'type' => 'text',
																			'identifier' => 'StandardNumberType',
																			'text' => 'ISBN'
																		),
																		
																		// StandardNumber
																		array (
																			'type' => 'text',
																			'identifier' => 'StandardNumber',
																			'text' => ''
																		),
																		
																		// Title
																		array (
																			'type' => 'text',
																			'identifier' => 'Title',
																			'text' => ''
																		),
																		
																		// AuthorGivenName
																		array (
																			'type' => 'text',
																			'identifier' => 'AuthorGivenName',
																			'text' => ''
																		),
																		
																		// AuthorFamily
																		array (
																			'type' => 'text',
																			'identifier' => 'AuthorFamily',
																			'text' => ''
																		),
																		
																		// PublicationYear
																		array (
																			'type' => 'text',
																			'identifier' => 'PublicationYear',
																			'text' => '1900'
																		),
																		
																		// Cost
																		array (
																			'type' => 'text',
																			'identifier' => 'Cost',
																			'text' => ''
																		),
																		
																		// JournalTitle
																		array (
																			'type' => 'text',
																			'identifier' => 'JournalTitle',
																			'text' => ''
																		),
																		
																		// JournalLink
																		array (
																			'type' => 'text',
																			'identifier' => 'JournalLink',
																			'text' => ''
																		),
																		
																		// InternetWebAddress
																		array (
																			'type' => 'text',
																			'identifier' => 'InternetWebAddress',
																			'text' => ''
																		),
																		
																		// Description
																		array (
																			'type' => 'text',
																			'identifier' => 'Description',
																			'text' => ''
																		),
																			   
																	)							   
																)
															), // End Recommended Resource Group
														)
													)
												), // End Recommended Group
											)
										)								
									), // End Resources Group
									
									// Grading Group
									array (
										'type' => 'group',
										'identifier' => 'Grading',
										'structuredDataNodes' => array (
											'structuredDataNode' => array (
												// Assignments Group
												array (
													'type' => 'group',
													'identifier' => 'Assignments',
													'structuredDataNodes' => array (
														'structuredDataNode' => array (
															// AssessmentAssignment Group
															array (
																'type' => 'group',
																'identifier' => 'AssessmentAssignment',
																'structuredDataNodes' => array (
																	'structuredDataNode' => array (
																		// Name
																		array (
																			'type' => 'text',
																			'identifier' => 'Name',
																			'text' => ''
																		),
																		
																		// Description
																		array (
																			'type' => 'text',
																			'identifier' => 'Description',
																			'text' => ''
																		),
																		
																		// PercentageOfTotalGrade
																		array (
																			'type' => 'text',
																			'identifier' => 'PercentageOfTotalGrade',
																			'text' => ''
																		),
																	)							   
																)
															), // End AssessmentAssignment Group
														)
													)
												), // End Assignments Group
												
												// Exams Group
												array (
													'type' => 'group',
													'identifier' => 'Exams',
													'structuredDataNodes' => array (
														'structuredDataNode' => array (
															// AssessmentExam Group
															array (
																'type' => 'group',
																'identifier' => 'AssessmentExam',
																'structuredDataNodes' => array (
																	'structuredDataNode' => array (
																		// Name
																		array (
																			'type' => 'text',
																			'identifier' => 'Name',
																			'text' => ''
																		),
																		
																		// Description
																		array (
																			'type' => 'text',
																			'identifier' => 'Description',
																			'text' => ''
																		),
																		
																		// PercentageOfTotalGrade
																		array (
																			'type' => 'text',
																			'identifier' => 'PercentageOfTotalGrade',
																			'text' => ''
																		),
																	)							   
																)
															), // End AssessmentExam Group
														)
													)
												), // End Exam Group
											)
										)								
									), // End Grading Group
								)
							)
							
						), // End Details Group
						
						// Related Courses Group
						array (
							'type' => 'group',
							'identifier' => 'RelatedCourses',
							'structuredDataNodes' => array (										
								'structuredDataNode' => array (
									// Prereequisites Group
									array (
										'type' => 'group',
										'identifier' => 'Prerequisites',
										'structuredDataNodes' => array (
											'structuredDataNode' => array (
												// Prerequisite
												array (
													'type' => 'text',
													'identifier' => 'Prerequisite',
													'text' => ''
												),
											)
										)
									), // End Prerequisites Group
									
									// Corequisites Group
									array (
										'type' => 'group',
										'identifier' => 'Corequisites',
										'structuredDataNodes' => array (
											'structuredDataNode' => array (
												// Corequsite
												array (
													'type' => 'text',
													'identifier' => 'Corequisite',
													'text' => ''
												),
											)
										)
									), // End Corequisties Group
															   
									// CrossListed Courses Group
									array (
										'type' => 'group',
										'identifier' => 'CrossListedCourses',
										'structuredDataNodes' => array (										
											'structuredDataNode' => array (
												// CrossListed
												array (
													'type' => 'text',
													'identifier' => 'CrossListed',
													'text' => $data_crosslisted
												),
												
												// CrossListedLink
												array (
													'type' => 'asset',
													'identifier' => 'CrossListedLink',
													'assetType' => 'page',
													'pagePath' => ''
												),
											)
										)
									), // End CrossListed Courses Group
									
									// LabCourses Group
									array (
										'type' => 'group',
										'identifier' => 'LabCourses',
										'structuredDataNodes' => array (
											'structuredDataNode' => array (
												// LabCourseLink
												array (
													'type' => 'asset',
													'identifier' => 'LabCourseLink',
													'assetType' => 'page',
													'pagePath' => ''
												),
											)
										)
									), // End LabCourses Group
								)
							)
							
						), // End Details Group
						
												
					) // End StructuredDataNode

				) // End StructuredDataNodes
				
			) // End StructuredData
		)
	);
	
	$params = array( 'authentication' => $auth,
					'asset' => $asset );
	
	try {
		$logStartTime = date('H:i:s');
		$startDateTime = strtotime(date('r'));
		
		$out = $service->create($params);
		
		if ( $out->createReturn->success != 'true' ) {
			$log .= '<h1 style="color:red;">Failed to create <strong>'.$data_section_system_name.'</strong> class section.</h1>';
			$log .= "<p>" .$out->createReturn->message . "</p>";
		}
		else
		{
			$log .= '<h1>Successful creation of <strong>'.$data_section_system_name.'</strong> class section.</h1>';

			// Include Access Code
			$which_access = 'full';
			include('../includes/set_access.php');
		}
		
			$logEndTime = date('H:i:s');
			$endDateTime = strtotime(date('r'));
			
			$timeDifference = $endDateTime - $startDateTime;
			
			$logDate = date('Y-m-d');
			$logFile = 'logs/create_'.$data_section_semester.'_'.$logDate.'.txt';
			$logHandle = fopen($logFile, 'a') or die("can't open file");
		
			$logData = date('r') . ", Asset: " .$data_section_system_name. ", Duration: " . $logStartTime . " - " . $logEndTime . ", Status: " . $out->createReturn->success . "; ". $out->createReturn->message . " - " . $timeDifference . " sec" . "\r\n";
			fwrite($logHandle, $logData);
			
			fclose($logHandle);
	}
	
	catch (Exception $e) {
		$log .= '<h1 style="color:red;">WSDL creation error on <strong>'.$data_section_system_name.'</strong> class section:</h1>';
		$log .= "<p>" . $e->getMessage() . "</p>";
	}

	echo $log;
?>



