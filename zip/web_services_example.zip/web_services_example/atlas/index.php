<?php
	session_start();
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
	<title>Web Services Atlas Menu</title>

    <link rel="stylesheet" type="text/css" href="../includes/style.css" />
    
</head>

<body>	
	<div class="headermenu">
    	<a href="logs.php"><img src="../images/view_logs.png" width="30" height="26" border="0"/><span style="vertical-align:bottom; padding:3px;">View Logs</span></a>
        &nbsp;&nbsp;
        <a href="logout.php"><img src="../images/reload.png" width="30" height="26" border="0"/><span style="vertical-align:bottom; padding:3px;">Reset Web Services Session</span></a>
    </div>
    
    <div class="menugroup">
    	<div class="fall">
        	<h2>Spring / Fall Semester</h2>
        	<ul>
				<? if($_SESSION['fall_create_all_class_sections']){ echo '<li class="completed">';} else {echo '<li class="incomplete">'; }?><a href="create_all_class_sections.php">Create / Edit Section Pages</a></li>
                <? if($_SESSION['fall_create_index_block_section_pages']){ echo '<li class="completed">';} else {echo '<li class="incomplete">'; }?><a href="create_index_block_section_pages.php">Create index block for ALL Section Pages</a></li>
                <? if($_SESSION['fall_create_index_blocks_by_subject']){ echo '<li class="completed">';} else {echo '<li class="incomplete">'; }?><a href="create_index_blocks_by_subject.php">Create index block for Sections by Subject</a></li>
                <? if($_SESSION['fall_create_department_pages']){ echo '<li class="completed">';} else {echo '<li class="incomplete">'; }?><a href="create_department_pages.php">Create Department Pages</a></li>
                <? if($_SESSION['fall_create_index_block_department_pages']){ echo '<li class="completed">';} else {echo '<li class="incomplete">'; }?><a href="create_index_block_department_pages.php">Create index block for ALL Department Pages</a></li>
                <? if($_SESSION['fall_create_departments_landing_page']){ echo '<li class="completed">';} else {echo '<li class="incomplete">'; }?><a href="create_departments_landing_page.php">Create &quot;Departments&quot; Landing Page</a></li>
                <? if($_SESSION['fall_create_ger_pages']){ echo '<li class="completed">';} else {echo '<li class="incomplete">'; }?><a href="create_ger_pages.php">Create GER Pages</a></li>
                <? if($_SESSION['fall_create_first_year_page']){ echo '<li class="completed">';} else {echo '<li class="incomplete">'; }?><a href="create_first_year_page.php">Create First Year Page</a></li>
                <? if($_SESSION['fall_create_semester_index_landing_page']){ echo '<li class="completed">';} else {echo '<li class="incomplete">'; }?><a href="create_semester_index_landing_page.php">Create Semester Index Landing Page</a></li>
        	</ul>
    	</div>
    </div>
    
    <div class="menugroup">
    	<div class="summer">
        	<h2>Summer Semester</h2>
        	<ul>
            	<? if($_SESSION['summer_create_all_class_sections']){ echo '<li class="completed">';} else {echo '<li class="incomplete">'; }?><a href="create_all_class_sections.php">Create / Edit Section Pages</a></li>
                <? if($_SESSION['summer_create_index_block_section_pages']){ echo '<li class="completed">';} else {echo '<li class="incomplete">'; }?><a href="create_index_block_section_pages_summer.php">Create index block for ALL Section Pages</a></li>
                <? if($_SESSION['summer_create_index_blocks_by_subject_all_sessions']){ echo '<li class="completed">';} else {echo '<li class="incomplete">'; }?><a href="create_index_blocks_by_subject_all_sessions.php">Create index block of ALL Sections by Subject for all Sessions</a></li>
                <? if($_SESSION['summer_create_department_pages_all_sessions']){ echo '<li class="completed">';} else {echo '<li class="incomplete">'; }?><a href="create_department_pages_all_sessions.php">Create Department Pages for all Sessions</a></li>
                <? if($_SESSION['summer_create_index_block_department_pages']){ echo '<li class="completed">';} else {echo '<li class="incomplete">'; }?><a href="create_index_block_department_pages.php">Create index block for ALL Department Pages</a></li>
               	<? if($_SESSION['summer_create_departments_landing_page']){ echo '<li class="completed">';} else {echo '<li class="incomplete">'; }?><a href="create_departments_landing_page.php">Create &quot;Departments&quot; Landing Page</a></li>
                <? if($_SESSION['summer_create_ger_pages']){ echo '<li class="completed">';} else {echo '<li class="incomplete">'; }?><a href="create_ger_pages.php">Create GER Pages</a></li>
                <? if($_SESSION['summer_create_first_year_page']){ echo '<li class="completed">';} else {echo '<li class="incomplete">'; }?><a href="create_first_year_page.php">Create First Year Page</a></li>
                <? if($_SESSION['summer_create_index_blocks_summer_sessions']){ echo '<li class="completed">';} else {echo '<li class="incomplete">'; }?><a href="create_index_blocks_summer_sessions.php">Create Index Blocks for Summer Sessions</a></li>
                <? if($_SESSION['summer_create_summer_sessions_pages']){ echo '<li class="completed">';} else {echo '<li class="incomplete">'; }?><a href="create_summer_sessions_pages.php">Create Summer Sessions Pages</a></li>
                <? if($_SESSION['summer_create_semester_index_landing_page']){ echo '<li class="completed">';} else {echo '<li class="incomplete">'; }?><a href="create_semester_index_landing_page.php">Create Semester Index Landing Page</a></li>
        	</ul>
    	</div>
    </div>
    
</body>
</html>

