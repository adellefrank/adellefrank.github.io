<?php
	session_start();
?>

<?php 
	ini_set('display_errors', 1);
	ini_set('log_errors', 1);
	error_reporting(E_ERROR | E_PARSE);
	set_time_limit(0);
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
	<title>Section Get CSV Data</title>

    <link rel="stylesheet" type="text/css" href="../includes/style.css" />

</head>

<body>

<?php 
	include("../includes/headermenu.php");
	
	echo "<h2>Create Semesters Index Landing Page</h2><hr />";
	
	$log = '';

	include '../includes/service.php';
	include '../includes/functions.php';

	if ($_REQUEST['submit']) {
		if ($_REQUEST['term_code']) {
			$start_webservices = true;
			$data_term_code = $_REQUEST['term_code'];
		} else {
			$start_webservices = false;
			$missing = true;
		}
	}
	
	if ($start_webservices == true) {		
		
		// Term Variables
		$trm_AR = str_split($data_term_code);
		$data_section_year = '20' . $trm_AR[1] . $trm_AR[2];
		$semester = $trm_AR[3];
		
		if ($semester == '1') {
			$data_section_semester = 'spring';
			$data_section_semester_desc = 'Spring';
		} elseif ($semester == '6') {
			$data_section_semester = 'summer';
			$data_section_semester_desc = 'Summer';							
		} elseif ($semester == '9') {
			$data_section_semester = 'fall';
			$data_section_semester_desc = 'Fall';
		}
		
		// Choose subnav block
		if ($semester == '6') {
			$subnav_block = '_internal/blocks/static/atlas/block_subnav_atlas_top_level_summer';
		} else {
			$subnav_block = '_internal/blocks/static/atlas/block_subnav_atlas_top_level_fall_spring';
		}		
		
		// Set Combination Variables
		$data_display_name = $data_section_semester_desc . ' ' . $data_section_year . ' Course Atlas - by Subject';
		$data_title = $data_section_semester_desc . ' ' . $data_section_year . ' Course Atlas - by Subject';
		$data_system_name = 'index';
		$data_parent_folder = 'academic/atlas/'.$data_section_year.'/'.$data_section_semester;
		$data_page_path = $data_parent_folder . '/' . $data_system_name;
		$data_metadata_set = 'default';
		if ($semester == '6') {
			$data_index_block = '_internal/blocks/static/atlas/block_atlas_subject_list_summer';
		} else {
			$data_index_block = '_internal/blocks/static/atlas/block_atlas_subject_list';
		}
		
		
		// Set Page Asset Information
		$asset = array( 
			'page' => array (
				'shouldBePublished' => true,
				'shouldBeIndexed' => true,
				'contentTypePath' => 'Page_Atlas',
				'parentFolderPath' => $data_parent_folder,
				'metadataSetPath' => $data_metadata_set,
				'name' => $data_system_name,
				'siteName' => 'College',
				'metadata' => array(
					'author' => 'Web Services',
					'displayName' => $data_display_name,
					'title' => $data_title,
				),
				
				'pageConfigurations' => array (
						'pageConfiguration' => array (
							'name' => 'HTML',
							'defaultConfiguration' => true,
							'templatePath' => '_internal/templates/college_secondary',
							'pageRegions' => array (
								'pageRegion' => array (
									// Default Region				   
									array (
										'name' => 'DEFAULT',
										'blockPath' => '_internal/blocks/index/block_index_current_page',
										'formatPath'=> '_internal/stylesheets/atlas/atlas_listing_landing',
									),
									// SubNav Region
									array (
										'name' => 'SUBNAV',
										'blockPath' => $subnav_block,
									),
								),
							),
						),
					),				
				
				'structuredData' => array (
					'definitionPath' => 'pagecontent',
					'structuredDataNodes' => array (													
						'structuredDataNode' => array (
					
							// Index Block
							array (
								'type' => 'asset',
								'identifier' => 'block-content',
								'assetType' => 'block',
								'blockPath' => $data_index_block
							), // End Catalog Course Connection
				
						) // End StructuredDataNode
	
					) // End StructuredDataNodes
					
				) // End StructuredData
				
			) // End Page
		);
		
		// Check to see if department page exists
		$path = array('path' => $data_page_path, 'siteName' => 'College');
		$id = array('path' => $path, 'type' => 'page');
		$readParams = array( 'authentication' => $auth, 'identifier' => $id );				
		
		$pageRead = $service->read($readParams);
					
		if ($pageRead->readReturn->success != 'true' ) {
	
			$params = array( 'authentication' => $auth,
							'asset' => $asset );
			
			try {
				$out = $service->create($params);
				
				if ( $out->createReturn->success != 'true' ) {
					$log .= '<h1 style="color:red;">Failed to create page.</h1>';
					$log .= "<p>" .$out->createReturn->message . "</p>";
				}
				else
				{
					$log .= '<h1>Successful creation of page.</h1>';
					
					// Include Access Code
					$which_access = 'limited';
					include('../includes/set_access.php');
					
					// Set Session Variable Completed
					if ($semester == '6') {
						$_SESSION['summer_create_semester_index_landing_page'] = true;
					} else {
						$_SESSION['fall_create_semester_index_landing_page'] = true;
					}
					
				}
			}
			
			catch (Exception $e) {
				$log .= '<h1 style="color:red;">WSDL creation error on page:</h1>';
				$log .= "<p>" . $e->getMessage() . "</p>";
			}

	echo $log;			
		} else {
			echo "The page exists";
		}
			
			
			
				
		
	
	} else {
?>
		<form enctype="multipart/form-data" action="<?php echo $PHP_SELF;?>" method="post" name="create_edit" target="_self">
			<div class="information">
<?php
					if ($missing) {
?>				
						<p style="color:red;">You must fill out all fields below.</p>
<?php
					}
?>
                <p>
                    Enter the term code to create an classes listings page for: 
                    <input name="term_code" type="text" value="<?php echo $_REQUEST['term_code']; ?>" size="10" maxlength="5" />
                </p>
                
                <p>
                    <input name="submit" type="submit" value="Start Web Services" />
                </p>
            </div>
		</form>
<?php
	} // End if ($start_webservices == true)
?>

</body>
</html>