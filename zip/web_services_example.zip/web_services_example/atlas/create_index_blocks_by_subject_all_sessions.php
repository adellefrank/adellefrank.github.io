<?php
	session_start();
?>

<?php 
	ini_set('display_errors', 1);
	ini_set('log_errors', 1);
	error_reporting(E_ERROR | E_PARSE);
	set_time_limit(0);
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
	<title>Section Get CSV Data</title>

    <link rel="stylesheet" type="text/css" href="../includes/style.css" />

</head>

<body>

<?php 
	include("../includes/headermenu.php");
	
	echo "<h2>Create index blocks for All Subjects</h2><hr />";

	include '../includes/service.php';
	include '../includes/functions.php';

	if ($_REQUEST['submit']) {
		if ($_REQUEST['term_code']) {
			$start_webservices = true;
			$data_term_code = $_REQUEST['term_code'];
		} else {
			$start_webservices = false;
			$missing = true;
		}
	}
	
	if ($start_webservices == true) {		
		
		// Term Variables
		$trm_AR = str_split($data_term_code);
		$data_section_year = '20' . $trm_AR[1] . $trm_AR[2];
		$semester = $trm_AR[3];
		
		if ($semester == '1') {
			$data_section_semester = 'spring';
			$data_section_semester_desc = 'Spring';
		} elseif ($semester == '6') {
			$data_section_semester = 'summer';
			$data_section_semester_desc = 'Summer';							
		} elseif ($semester == '9') {
			$data_section_semester = 'fall';
			$data_section_semester_desc = 'Fall';
		}
		
		include('../includes/subject_code_array.php');
				
		foreach($department_AR as $thisDepartment) {
			$data_department = get_department($thisDepartment);
			$data_department_desc = get_department($thisDepartment,'desc');
		
			// Set Combination Variables
			$data_metadata_set = '';
			$data_parent_folder = '_internal/blocks/index/class_sections_atlases/subject';
	
			// Regular Session Index
			$log = '';
			$data_display_name = $data_department_desc . ' - Directed Study and Study Abroad';
			$data_title = $data_department .'_regular';
			$data_system_name = 'block_'.$thisDepartment.'_' . $data_term_code . '_regular';
			$data_index_block = $data_parent_folder .'/'. $data_system_name;
			$data_index_folder = 'academic/atlas/'.$data_section_year.'/'.$data_section_semester.'/section/regular/'.$data_department;
			
			$asset = array( 
				'indexBlock' => array (
					'name' => $data_system_name,
					'siteName' => 'College',
					'parentFolderPath' => $data_parent_folder,
					'metadataSetPath' => $data_metadata_set,
					'metadata' => array(
						'author' => 'Web Services',
						'displayName' => $data_display_name,
						'title' => $data_title,
					),
					
					'indexBlockType' => 'folder',
					'indexedFolderPath' => $data_index_folder,
					'maxRenderedAssets' => 0,
					'depthOfIndex' => 5,
					'includePageContent' => false,
					'includeCurrentPageXML' => false,
					'renderCurrentPageAndHierarchy' => false,
					'includeChildrenInHierarchy' => false,
					'indexPages' => true,
					'indexBlocks' => false,
					'indexLinks' => false,
					'indexFiles' => false,
					'indexRegularContent' => true,
					'indexSystemMetadata' => false,
					'indexUserMetadata' => true,
					'indexAccessRights' => false,
					'indexUserInfo' => false,
					'indexWorkflowInfo' => false,
					'appendCallingPageData' => false ,
					'sortMethod' => 'alphabetical',
					'sortOrder' => 'ascending',
				)
			);				
			
			// Check to see if index exists
			$path = array('path' => $data_index_block, 'siteName' => 'College');
			$id = array('path' => $path, 'type' => 'block');
			$readParams = array( 'authentication' => $auth, 'identifier' => $id );				
			
			$indexRead = $service->read($readParams);
						
			if ($indexRead->readReturn->success != 'true' ) {
		
				$params = array( 'authentication' => $auth,
								'asset' => $asset );
				
				try {
					$out = $service->create($params);
					
					if ( $out->createReturn->success != 'true' ) {
						$log .= '<h1 style="color:red;">Failed to create <strong>REGULAR</strong> index block for '.$thisDepartment.' subject.</h1>';
						$log .= "<li>" .$out->createReturn->message . "</li>";
					}
					else
					{
						$log .= '<h1>Successful creation of <strong>REGULAR</strong> index block for '.$thisDepartment.' subject.</h1>';
					}
				}
				
				catch (Exception $e) {
					$log .= '<h1 style="color:red;">WSDL creation error on <strong>REGULAR</strong> index block for '.$thisDepartment.' subject:</h1>';
					$log .= "<li>" . $e->getMessage() . "</li>";
				}
		
				echo $log;			
			} else {
				echo '<h1>The <strong>REGULAR</strong> index block for '.$thisDepartment.' subject exists</h1>';
			}
			
			// 6W1 Session Index
			$log = '';
			$data_display_name = $data_department_desc . ' - 6W1 Session';
			$data_title = $data_department .'_6W1';			
			$data_system_name = 'block_'.$thisDepartment.'_' . $data_term_code . '_6W1';
			$data_index_block = $data_parent_folder .'/'. $data_system_name;
			$data_index_folder = 'academic/atlas/'.$data_section_year.'/'.$data_section_semester.'/section/6W1/'.$data_department;
			
			$asset = array( 
				'indexBlock' => array (
					'name' => $data_system_name,
					'siteName' => 'College',
					'parentFolderPath' => $data_parent_folder,
					'metadataSetPath' => $data_metadata_set,
					'metadata' => array(
						'author' => 'Web Services',
						'displayName' => $data_display_name,
						'title' => $data_title,
					),
					
					'indexBlockType' => 'folder',
					'indexedFolderPath' => $data_index_folder,
					'maxRenderedAssets' => 0,
					'depthOfIndex' => 5,
					'includePageContent' => false,
					'includeCurrentPageXML' => false,
					'renderCurrentPageAndHierarchy' => false,
					'includeChildrenInHierarchy' => false,
					'indexPages' => true,
					'indexBlocks' => false,
					'indexLinks' => false,
					'indexFiles' => false,
					'indexRegularContent' => true,
					'indexSystemMetadata' => false,
					'indexUserMetadata' => true,
					'indexAccessRights' => false,
					'indexUserInfo' => false,
					'indexWorkflowInfo' => false,
					'appendCallingPageData' => false ,
					'sortMethod' => 'alphabetical',
					'sortOrder' => 'ascending',
				)
			);				
			
			// Check to see if index exists
			$path = array('path' => $data_index_block, 'siteName' => 'College');
			$id = array('path' => $path, 'type' => 'block');
			$readParams = array( 'authentication' => $auth, 'identifier' => $id );				
			
			$indexRead = $service->read($readParams);
						
			if ($indexRead->readReturn->success != 'true' ) {
		
				$params = array( 'authentication' => $auth,
								'asset' => $asset );
				
				try {
					$out = $service->create($params);
					
					if ( $out->createReturn->success != 'true' ) {
						$log .= '<h1 style="color:red;">Failed to create <strong>6W1</strong> index block for '.$thisDepartment.' subject.</h1>';
						$log .= "<li>" .$out->createReturn->message . "</li>";
					}
					else
					{
						$log .= '<h1>Successful creation of <strong>6W1</strong> index block for '.$thisDepartment.' subject.</h1>';
					}
				}
				
				catch (Exception $e) {
					$log .= '<h1 style="color:red;">WSDL creation error on <strong>6W1</strong> index block for '.$thisDepartment.' subject:</h1>';
					$log .= "<li>" . $e->getMessage() . "</li>";
				}
		
				echo $log;			
			} else {
				echo '<h1>The <strong>6W1</strong> index block for '.$thisDepartment.' subject exists</h1>';
			}
			
		// 6W2 Session Index
			$log = '';
			$data_display_name = $data_department_desc . ' - 6W2 Session';
			$data_title = $data_department .'_6W2';				
			$data_system_name = 'block_'.$thisDepartment.'_' . $data_term_code . '_6W2';
			$data_index_block = $data_parent_folder .'/'. $data_system_name;
			$data_index_folder = 'academic/atlas/'.$data_section_year.'/'.$data_section_semester.'/section/6W2/'.$data_department;
			
			$asset = array( 
				'indexBlock' => array (
					'name' => $data_system_name,
					'siteName' => 'College',
					'parentFolderPath' => $data_parent_folder,
					'metadataSetPath' => $data_metadata_set,
					'metadata' => array(
						'author' => 'Web Services',
						'displayName' => $data_display_name,
						'title' => $data_title,
					),
					
					'indexBlockType' => 'folder',
					'indexedFolderPath' => $data_index_folder,
					'maxRenderedAssets' => 0,
					'depthOfIndex' => 5,
					'includePageContent' => false,
					'includeCurrentPageXML' => false,
					'renderCurrentPageAndHierarchy' => false,
					'includeChildrenInHierarchy' => false,
					'indexPages' => true,
					'indexBlocks' => false,
					'indexLinks' => false,
					'indexFiles' => false,
					'indexRegularContent' => true,
					'indexSystemMetadata' => false,
					'indexUserMetadata' => true,
					'indexAccessRights' => false,
					'indexUserInfo' => false,
					'indexWorkflowInfo' => false,
					'appendCallingPageData' => false ,
					'sortMethod' => 'alphabetical',
					'sortOrder' => 'ascending',
				)
			);				
			
			// Check to see if index exists
			$path = array('path' => $data_index_block, 'siteName' => 'College');
			$id = array('path' => $path, 'type' => 'block');
			$readParams = array( 'authentication' => $auth, 'identifier' => $id );				
			
			$indexRead = $service->read($readParams);
						
			if ($indexRead->readReturn->success != 'true' ) {
		
				$params = array( 'authentication' => $auth,
								'asset' => $asset );
				
				try {
					$out = $service->create($params);
					
					if ( $out->createReturn->success != 'true' ) {
						$log .= '<h1 style="color:red;">Failed to create <strong>6W2</strong> index block for '.$thisDepartment.' subject.</h1>';
						$log .= "<li>" .$out->createReturn->message . "</li>";
					}
					else
					{
						$log .= '<h1>Successful creation of <strong>6W2</strong> index block for '.$thisDepartment.' subject.</h1>';
						// Set Session Variable Completed
						if ($semester == '6') {
							$_SESSION['summer_create_index_blocks_by_subject_all_sessions'] = true;
						} else {
							$_SESSION['fall_create_index_blocks_by_subject_all_sessions'] = true;
						}
					}
				}
				
				catch (Exception $e) {
					$log .= '<h1 style="color:red;">WSDL creation error on <strong>6W2</strong> index block for '.$thisDepartment.' subject:</h1>';
					$log .= "<li>" . $e->getMessage() . "</li>";
				}
		
				echo $log;			
			} else {
				echo '<h1>The <strong>6W2</strong> index block for '.$thisDepartment.' subject exists</h1>';
			}			
		
		} // End foreach	
	} else {
?>
		<form enctype="multipart/form-data" action="<?php echo $PHP_SELF;?>" method="post" name="create_edit" target="_self">
			<div class="information">
<?php
					if ($missing) {
?>				
						<p style="color:red;">You must fill out all fields below.</p>
<?php
					}
?>
                <p>
                    Enter the term code to create the index blocks: 
                    <input name="term_code" type="text" value="<?php echo $_REQUEST['term_code']; ?>" size="10" maxlength="5" />
                </p>
                
                <p>
                    <input name="submit" type="submit" value="Start Web Services" />
                </p>
            </div>
		</form>
<?php
	} // End if ($start_webservices == true)
?>

</body>
</html>