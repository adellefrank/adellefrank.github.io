<?php
	session_start();
?>

<?php 
	ini_set('display_errors', 1);
	ini_set('log_errors', 1);
	error_reporting(E_ERROR | E_PARSE);
	set_time_limit(0);
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
	<title>Section Get CSV Data</title>

    <link rel="stylesheet" type="text/css" href="../includes/style.css" />

</head>

<body>

<?php 
	include("../includes/headermenu.php");
	
	echo "<h2>Create index block for ALL sections</h2><hr />";


	$log = '';

	include '../includes/service.php';
	include '../includes/functions.php';

	if ($_REQUEST['submit']) {
		if ($_REQUEST['term_code']) {
			$start_webservices = true;
			$data_term_code = $_REQUEST['term_code'];
		} else {
			$start_webservices = false;
			$missing = true;
		}
	}
	
	if ($start_webservices == true) {		
		
		// Term Variables
		$trm_AR = str_split($data_term_code);
		$data_section_year = '20' . $trm_AR[1] . $trm_AR[2];
		$semester = $trm_AR[3];
		
		if ($semester == '1') {
			$data_section_semester = 'spring';
			$data_section_semester_desc = 'Spring';
		} elseif ($semester == '6') {
			$data_section_semester = 'summer';
			$data_section_semester_desc = 'Summer';							
		} elseif ($semester == '9') {
			$data_section_semester = 'fall';
			$data_section_semester_desc = 'Fall';
		}
		
		// Set Combination Variables
		$data_display_name = $data_section_semester_desc . ' ' . $data_section_year . 'Course Catalog Listing';
		$data_title = $data_section_semester_desc . ' ' . $data_section_year . 'Course Catalog Listing';
		$data_system_name = 'block_sections_' . $data_term_code;
		$data_parent_folder = '_internal/blocks/index/class_sections_atlases';
		$data_index_block = $data_parent_folder .'/'. $data_system_name;
		$data_metadata_set = '';
		$data_index_folder = 'academic/atlas/'.$data_section_year.'/'.$data_section_semester.'/section';
		
		$asset = array( 
			'indexBlock' => array (
				'name' => $data_system_name,
				'siteName' => 'College',
				'parentFolderPath' => $data_parent_folder,
				'metadataSetPath' => $data_metadata_set,
				'metadata' => array(
					'author' => 'Web Services',
					'displayName' => $data_display_name,
					'title' => $data_title,
				),
				
				'indexBlockType' => 'folder',
				'indexedFolderPath' => $data_index_folder,
				'maxRenderedAssets' => 0,
				'depthOfIndex' => 5,
				'includePageContent' => false,
				'includeCurrentPageXML' => false,
				'renderCurrentPageAndHierarchy' => false,
				'includeChildrenInHierarchy' => false,
				'indexPages' => true,
				'indexBlocks' => false,
				'indexLinks' => false,
				'indexFiles' => false,
				'indexRegularContent' => true,
				'indexSystemMetadata' => false,
				'indexUserMetadata' => true,
				'indexAccessRights' => false,
				'indexUserInfo' => false,
				'indexWorkflowInfo' => false,
				'appendCallingPageData' => false ,
				'sortMethod' => 'alphabetical',
				'sortOrder' => 'ascending',
			)
		);
		
		// Check to see if index exists
		$path = array('path' => $data_index_block, 'siteName' => 'College');
		$id = array('path' => $path, 'type' => 'block');
		$readParams = array( 'authentication' => $auth, 'identifier' => $id );				
		
		$indexRead = $service->read($readParams);
					
		if ($indexRead->readReturn->success != 'true' ) {
	
			$params = array( 'authentication' => $auth,
							'asset' => $asset );
			
			try {
				$out = $service->create($params);
				
				if ( $out->createReturn->success != 'true' ) {
					$log .= '<h1 style="color:red;">Failed to create index block for Atlas Class Sections.</h1>';
					$log .= "<p>" .$out->createReturn->message . "</p>";
				}
				else
				{
					$log .= '<h1>Successful creation of index block for Atlas Class Sections.</h1>';
					
					// Set Session Variable Completed
					if ($semester == '6') {
						$_SESSION['summer_create_index_block_section_pages'] = true;
					} else {
						$_SESSION['fall_create_index_block_section_pages'] = true;
					}
				}
			}
			
			catch (Exception $e) {
				$log .= '<h1 style="color:red;">WSDL creation error on index block for Atlas Class Sections:</h1>';
				$log .= "<p>" . $e->getMessage() . "</p>";
			}
	
			echo $log;			
		} else {
			echo "The index block for Atlas Class Sections exists";
		}
	
	} else {
?>
		<form enctype="multipart/form-data" action="<?php echo $PHP_SELF;?>" method="post" name="create_edit" target="_self">
			<div class="information">
<?php
					if ($missing) {
?>				
						<p style="color:red;">You must fill out all fields below.</p>
<?php
					}
?>
                <p>
                    Enter the term code to create an index block for: 
                    <input name="term_code" type="text" value="<?php echo $_REQUEST['term_code']; ?>" size="10" maxlength="5" />
                </p>
                
                <p>
                    <input name="submit" type="submit" value="Start Web Services" />
                </p>
            </div>
		</form>
<?php
	} // End if ($start_webservices == true)
?>

</body>
</html>