<?php 
	ini_set('display_errors', 1);
	ini_set('log_errors', 1);
	error_reporting(E_ALL);
	set_time_limit(0);
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title>Catalog CSV List</title>
</head>

<body>
	
<?php 
	include 'functions.php';
	
	$showheadings = true;
				
	$handle = fopen("new_EU_SR_UCOL_WEB_CATALOG_INFO.csv", "r");
	
	while (($data = fgetcsv($handle, 1000, ",")) !== FALSE) {
	
		// Set Columns
		if ($data[0] == 'Subject') {
			$num = count($data);             
		 
			for ($c=0; $c < $num; $c++) {
				switch ($data[$c]) {
					case "Subject":
						$subject = $c;
						break;
					case "Catalog":
						$catalog =$c;
						break;
					case "Descr":
						$descr =$c;
						break;
					case "Topic ID":
						$topic_id =$c;
						break;
					case "Min Units":
						$min_units =$c;
						break;
					case "Max Units":
						$max_units =$c;
						break;
					case "Grading":
						$grading =$c;
						break;
					case "Course ID":
						$course_id =$c;
						break;
					case "Designation":
						$designation =$c;
						break;
					case "Prerequisite":
						$prerequisite =$c;
						break;
					case "Typically Offer":
						$typically_offer =$c;
						break;
					case "Consent":
						$consent =$c;
						break;
					case "CrossListing":
						$crosslisting =$c;
						break;
				}
			}
			
		} else {         
			
			// Set Variables From Spreadsheet
				if ($data[$subject]) { $data_subject = $data[$subject]; } else { $data_subject = ""; }
				if ($data[$catalog]) { $data_catalog = $data[$catalog]; } else { $data_catalog = ""; }
				if ($data[$descr]) { $data_descr = $data[$descr]; } else { $data_descr = ""; }
				if ($data[$topic_id]) { $data_topic_id = $data[$topic_id]; } else { $data_topic_id = ""; }
				if ($data[$min_units]) { $data_min_units = $data[$min_units]; } else { $data_min_units = "4"; }
				if ($data[$max_units]) { $data_max_units = $data[$max_units]; } else { $data_max_units = "4"; }
				if ($data[$grading]) { $data_grading = $data[$grading]; } else { $data_grading = "OPT"; }
				if ($data[$course_id]) { $data_course_id = $data[$course_id]; } else { $data_course_id = ""; }
				if ($data[$designation]) { $data_designation = $data[$designation]; } else { $data_designation = ""; }
				if ($data[$prerequisite]) { $data_prerequisite = $data[$prerequisite]; } else { $data_prerequisite = ""; }
				if ($data[$typically_offer]) { $data_typically_offer = $data[$typically_offer]; } else { $data_typically_offer = "Y"; }
				if ($data[$consent]) { $data_consent = $data[$consent]; } else { $data_consent = "No Special Consent Required"; }
				if ($data[$crosslisting]) { $data_crosslisting = $data[$crosslisting]; } else { $data_crosslisting = ""; }

					
			// Set Folder Asset
				include ('course_switch.php');
				
			
			// Get Crosslistings
				$crosslisted_courses_AR = array();
				$crosslisting_handle = fopen("new_EU_SR_UCOL_WEB_CATALOG_INFO.csv", "r");
	
				while (($crosslisting_data = fgetcsv($crosslisting_handle, 1000, ",")) !== FALSE) {
	
				// Set Columns
					if ($crosslisting_data[0] == 'Subject') {
						// exclude headings
					} else {         
						
						if ($crosslisting_data[$course_id] == $data[$course_id]) {
							// Set Variables From Spreadsheet
							if ($crosslisting_data[$subject]) { $crosslisting_data_subject = $crosslisting_data[$subject]; } else {$crosslisting_data_subject = ''; }
							if ($crosslisting_data[$catalog]) { $crosslisting_data_catalog = $crosslisting_data[$catalog]; } else {$crosslisting_data_catalog = ''; }
							
							// Set Course Path
							$full_department = get_department($crosslisting_data_subject);
							$full_department_path = "academic/course/" . $full_department . "/";
							
							
							// Add to Crosslisting Array
							if (($crosslisting_data_subject . $crosslisting_data_catalog) == ($data_subject . $data_catalog)) {
								// Don't add self to crosslisting
							} else { 
								$crosslisted_courses_info = $full_department_path . $crosslisting_data_subject . $crosslisting_data_catalog;
								array_push($crosslisted_courses_AR, $crosslisted_courses_info);
							}
						} 
					}
				// End Set Columns
				}
				fclose($crosslisting_handle);
			// End Get Crosslistings	
			
			
			
		   
			$listing = "";
		
			if ($data[$subject]) {
				$listing .= "Subject = " . $data[$subject] . "<br/> ";
			}
			
			if ($data[$catalog]) {
				$listing .= "Catalog = " . $data[$catalog] . "<br/> ";
			}
			
			if ($data[$descr]) {
				$listing .= "Descr = " . $data[$descr] . "<br/> ";
			}
			
			if ($data[$topic_id]) {
				$listing .= "Topic ID = " . $data[$topic_id] . "<br/> ";
			}
			
			if ($data[$min_units]) {
				$listing .= "Min Units = " . $data[$min_units] . "<br/> ";
			}
			
			if ($data[$max_units]) {
				$listing .= "Max Units = " . $data[$max_units] . "<br/> ";
			}
			
			if ($data[$grading]) {
				$listing .= "Grading = " . $data[$grading] . "<br/> ";
			}
			
			if ($data[$course_id]) {
				$listing .= "Course ID = " . $data[$course_id] . "<br/> ";
			}
			
			if ($data[$designation]) {
				$listing .= "Designation = " . $data[$designation] . "<br/> ";
			}
			
			if ($data[$prerequisite]) {
				$listing .= "Prerequisite = " . $data[$prerequisite] . "<br/> ";
			}
			
			if ($data[$typically_offer]) {
				$listing .= "Typically Offered = " . $data[$typically_offer] . "<br/> ";
			}
			
			if ($data[$consent]) {
				$listing .= "Consent = " . $data[$consent] . "<br/> ";
			}
			
			if ($data[$crosslisting]) {
				$listing .= "CrossListing = " . $data[$crosslisting] . "<br/> ";
			}
			
			if ($crosslisted_courses_AR) {
				$listing .= "Cross Listed Courses = <br/> ";
				
				foreach ($crosslisted_courses_AR as $this_course) {
					$listing .=  $this_course . "<br>";
				}				
			}
			
			$listing .= "<br /><br />";
			if ($crosslisted_courses_AR) {
				echo $listing;
			}
		}
	}
	
	fclose($handle);
	
?>


</body>
</html>