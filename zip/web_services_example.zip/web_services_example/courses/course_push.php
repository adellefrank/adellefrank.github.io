<?php 
	//ini_set('display_errors', 1);
	ini_set('log_errors', 1);
	error_reporting(E_ALL);
	set_time_limit(0);
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title>Catalog CSV List</title>

<style type="text/css">
	div.information {
		border:solid 1px #666666;
		padding:10px;
	}
</style>

</head>

<body>

<?php 

	include( '../includes/service.php');
	include('../includes/functions.php');
	
	if ($_REQUEST['submit']) {
		if ($_REQUEST['action']) {
			$start_webservices = true;
		} else {
			$start_webservices = false;
			$missing = true;
		}
	}
	
	if ($start_webservices == true) {	
		$showheadings = true;
					
		$handle = fopen("new_EU_SR_UCOL_WEB_CATALOG_INFO.csv", "r");
		
		while (($data = fgetcsv($handle, 1000, ",")) !== FALSE) {
		
			// Set Columns
			if ($data[0] == 'Subject') {
				$num = count($data);             
			 
				for ($c=0; $c < $num; $c++) {
					switch ($data[$c]) {
						case "Subject":
							$subject = $c;
							break;
						case "Catalog":
							$catalog =$c;
							break;
						case "Descr":
							$descr =$c;
							break;
						case "Topic ID":
							$topic_id =$c;
							break;
						case "Min Units":
							$min_units =$c;
							break;
						case "Max Units":
							$max_units =$c;
							break;
						case "Grading":
							$grading =$c;
							break;
						case "Course ID":
							$course_id =$c;
							break;
						case "Designation":
							$designation =$c;
							break;
						case "Prerequisite":
							$prerequisite =$c;
							break;
						case "Typically Offer":
							$typically_offer =$c;
							break;
						case "Consent":
							$consent =$c;
							break;
						case "CrossListing":
							$crosslisting =$c;
							break;
					}
				}
				
			} else {
			
				if (($data[$subject] == 'AAAA') || 
					($data[$subject] == 'ARCH') ||
					($data[$subject] == 'BUS')	||
					($data[$subject] == 'CIPA') ||
					($data[$subject] == 'EAP') ||
					($data[$subject] == 'FAME') ||
					($data[$subject] == 'GENEDRQT') ||
					($data[$subject] == 'NRSG') || 
					($data[$subject] == 'NS') ||
					($data[$subject] == 'OCFT')	||
					($data[$subject] == 'OTHCRD') ||
					($data[$subject] == 'PRECOL') ||
					($data[$subject] == 'RES') ||
					($data[$subject] == 'ROCT') ||	
					($data[$subject] == 'TRANSFER') ||
					($data[$subject] == 'VS')
					) {
					// Ignore these Subject Abbreviations
				} else {       
					
					if ($data[$topic_id] > 1) {
						// Ignore Courses whose topic ID is greater than 
					} else {		
						if (string_begins_with($data[$catalog], '9')) {
							// Ignore Courses whose catalog number begins with a nine
						} else {
							
							// Set Variables From Spreadsheet
								if ($data[$subject]) { $data_subject = $data[$subject]; } else { $data_subject = ""; }
								if ($data[$catalog]) { $data_catalog = $data[$catalog]; } else { $data_catalog = ""; }
								if ($data[$descr]) { $data_descr = $data[$descr]; } else { $data_descr = ""; }
								if ($data[$topic_id]) { $data_topic_id = $data[$topic_id]; } else { $data_topic_id = ""; }
								if ($data[$min_units]) { $data_min_units = $data[$min_units]; } else { $data_min_units = "4"; }
								if ($data[$max_units]) { $data_max_units = $data[$max_units]; } else { $data_max_units = "4"; }
								if ($data[$grading]) { $data_grading = $data[$grading]; } else { $data_grading = "OPT"; }
								if ($data[$course_id]) { $data_course_id = $data[$course_id]; } else { $data_course_id = ""; }
								if ($data[$designation]) { $data_designation = $data[$designation]; } else { $data_designation = ""; }
								if ($data[$prerequisite]) { $data_prerequisite = $data[$prerequisite]; } else { $data_prerequisite = ""; }
								if ($data[$typically_offer]) { $data_typically_offer = $data[$typically_offer]; } else { $data_typically_offer = "Y"; }
								if ($data[$consent]) { $data_consent = $data[$consent]; } else { $data_consent = "No Special Consent Required"; }
								if ($data[$crosslisting]) { $data_crosslisting = $data[$crosslisting]; } else { $data_crosslisting = ""; }
				
									
							// Set Folder Asset
								include ('course_switch.php');
								
							// Get Crosslistings
								$crosslisted_courses_AR = array();
								$crosslisting_handle = fopen("new_EU_SR_UCOL_WEB_CATALOG_INFO.csv", "r");
					
								while (($crosslisting_data = fgetcsv($crosslisting_handle, 1000, ",")) !== FALSE) {
					
								// Set Columns
									if ($crosslisting_data[0] == 'Subject') {
										// exclude headings
									} else {         
										if ($crosslisting_data[$course_id] == $data[$course_id]) {
											// Set Variables From Spreadsheet
											if ($crosslisting_data[$subject]) { $crosslisting_data_subject = $crosslisting_data[$subject]; } else {$crosslisting_data_subject = ''; }
											if ($crosslisting_data[$catalog]) { $crosslisting_data_catalog = $crosslisting_data[$catalog]; } else {$crosslisting_data_catalog = ''; }
											
											// Set Course Path
											$full_department = get_department($crosslisting_data_subject);
											$full_department_path = "academic/course/" . $full_department . "/";
											
											// Add to Crosslisting Array
											if (($crosslisting_data_subject . $crosslisting_data_catalog) == ($data_subject . $data_catalog)) {
												// Don't add self to crosslisting
											} else { 
												$crosslisted_courses_info = $full_department_path . $crosslisting_data_subject . $crosslisting_data_catalog;
												array_push($crosslisted_courses_AR, $crosslisted_courses_info);
											}
										} 
									}
								// End Set Columns
								}
								fclose($crosslisting_handle);
							// End Get Crosslistings	
								
							// Set Combination Variables
								$data_display_name = $data_subject . ' ' . $data_catalog . ': ' . $data_descr;
								$data_system_name = $data_subject . $data_catalog;
								$data_parent_folder = "academic/course/" . $data_subject_folder_name;
								$data_expiration_folder = "academic/course/" . $data_subject_folder_name;
								$data_metadata_set = "courses";
								$data_description = "Description";
								$data_catalog_folder = "academic/course";
								$data_currently_offered = "Y";
								$data_school_name = "UndergraduateEmoryCollege";
								$data_cross_listed_courses = "";
								$data_prerequisite = "";
								$data_cross_listing_id = "";
						
							// Check for Subject Folder			
								if ($_REQUEST['action'] == 'create') {
									$path = array('path' => $data_parent_folder, 'siteName' =>'');
									$id = array('path' => $path, 'type' => 'folder');
									$readParams = array( 'authentication' => $auth, 'identifier' => $id );				
									
									$folderRead = $service->read($readParams);
												
									if ( $folderRead->readReturn->success != 'true' ) {
										// Create The Subject Folder
											$folderAsset = array( 
												'folder' => array (
													'shouldBePublished' => true,
													'shouldBeIndexed' => true,
													'expirationFolderPath' => $data_catalog_folder,
													'parentFolderPath' => $data_catalog_folder,
													'name' => $data_subject_folder_name,
													'siteName' => '',
													'metadataSetPath' => 'Default',
													'metadata' => array(
														'author' => 'Web Services',
														'displayName' => $data_subject_full_name,
														'title' => $data_subject_full_name
													)
												)
											);
											
											$createParams = array( 'authentication' => $auth, 'asset' => $folderAsset );	
											$folderCreate = $service->create($createParams);
											
											if ( $folderCreate->createReturn->success == 'true' ) {
												echo "<h1>Created ". $data_subject ." Folder.</h1>";
											}
										// End Create The Subject Folder
									} else {
										echo '<h1>I found '.$data_subject_folder_name.' folder</h1>';
									}
								}
							// End Check for Subject Folder				
				
							// Include Specific Web Services Actions
								if ($_REQUEST['action'] == 'create') {
									// Add Course Data
									include ('add_course.php');	
								} elseif ($_REQUEST['action'] == 'edit') { 						
									// Edit Course Data
									include ('edit_course.php');			
								}
						   
							$listing = '<div class="information"><ul>';
						
							if ($data[$subject]) {
								$listing .= "<li>Subject = " . $data[$subject] . "</li> ";
							}
							
							if ($data[$catalog]) {
								$listing .= "<li>Catalog = " . $data[$catalog] . "</li> ";
							}
							
							if ($data[$descr]) {
								$listing .= "<li>Descr = " . $data[$descr] . "</li> ";
							}
							
							if ($data[$topic_id]) {
								$listing .= "<li>Topic ID = " . $data[$topic_id] . "</li> ";
							}
							
							if ($data[$min_units]) {
								$listing .= "<li>Min Units = " . $data[$min_units] . "</li> ";
							}
							
							if ($data[$max_units]) {
								$listing .= "<li>Max Units = " . $data[$max_units] . "</li> ";
							}
							
							if ($data[$grading]) {
								$listing .= "<li>Grading = " . $data[$grading] . "</li> ";
							}
							
							if ($data[$course_id]) {
								$listing .= "<li>Course ID = " . $data[$course_id] . "</li> ";
							}
							
							if ($data[$designation]) {
								$listing .= "<li>Designation = " . $data[$designation] . "</li> ";
							}
							
							if ($data[$prerequisite]) {
								$listing .= "<li>Prerequisite = " . $data[$prerequisite] . "</li> ";
							}
							
							if ($data[$typically_offer]) {
								$listing .= "<li>Typically Offered = " . $data[$typically_offer] . "</li> ";
							}
							
							if ($data[$consent]) {
								$listing .= "<li>Consent = " . $data[$consent] . "</li> ";
							}
							
							if ($data[$crosslisting]) {
								$listing .= "<li>CrossListing = " . $data[$crosslisting] . "</li> ";
							}
							
							if ($crosslisted_courses_AR) {
								$listing .= "<li>Cross Listed Courses = <ul> ";
								
								foreach ($crosslisted_courses_AR as $this_course) {
									$listing .=  "<li>" . $this_course . "</li>";
								}	
								$listing .= "</ul></li>";			
							}
							
							$listing .= "</ul></div>";
																
							// Display different stuff depending on action
							if ($_REQUEST['action'] == 'create') {
								echo $listing;
							} elseif ($_REQUEST['action'] == 'edit') { 						
								if ($crosslisted_courses_AR) {
									echo $listing;
								}			
							}
							
						} // End if (string_begins_with($data_catalog, '9'))
					
					} // End if ($data[$topic_id] > 1)
					
				} // End if (($data[$subject] ==
				
			} // End if ($data[0] == 'Subject')
			
		} // End while (($data = fgetcsv($handle, 1000, ",")) !== FALSE)
		
		fclose($handle);
	} else {
?>
		<form action="course_push.php" method="post" name="create_edit" target="_self">
			<div class="information">
<?
					if ($missing) {
?>				
						<p style="color:red;">You must select on of the actions below.</p>
<?
					}
?>
                <p>
                    Do you want to 
                    <input name="action" type="radio" value="create"/>CREATE 
                    or 
                    <input name="action" type="radio" value="edit" />EDIT 
                    Courses with Web Services? 
                </p>
                <p>
                    <input name="submit" type="submit" value="Start Web Services" />
                </p>
            </div>
		</form>
<?
	}
?>
</body>
</html>