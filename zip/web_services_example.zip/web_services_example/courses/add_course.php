<?php	
	$log = '';
	
	// Set Page Asset Information
	$asset = array( 
		'page' => array (
			'shouldBePublished' => true,
			'shouldBeIndexed' => true,
			'contentTypePath' => 'courseCatalog',
			'parentFolderPath' => $data_parent_folder,
			'metadataSetPath' => 'data_metadata_set',
			'expirationFolderPath' => $data_expiration_folder,
			'name' => $data_system_name,
			'siteName' => 'College',
			'metadata' => array(
				'author' => 'Web Services',
				'displayName' => $data_display_name,
				'title' => $data_display_name,
				'dynamicFields' => array (
					'dynamicField' => array (
						'name' => 'GER',
						'fieldValues' => array (
							'fieldValue' => array (
								'value' => $data_designation
							)
						)
					)
				)
			),
			
			'structuredData' => array (
				'definitionPath' => 'course_catalog',
				'structuredDataNodes' => array (													
					'structuredDataNode' => array (
						
						// Number Group
						array (
							'type' => 'group',
							'identifier' => 'Number',
							'structuredDataNodes' => array (										
								'structuredDataNode' => array (
									// Subject
									array (
										'type' => 'text',
										'identifier' => 'SubjectAbbreviation',
										'text' => $data_subject
									),
							
									// Catalog Number
									array (
										'type' => 'text',
										'identifier' => 'CatalogNumber',
										'text' => $data_catalog 
									)
								)								
							) 
						), //End Number Group
						
						// Title Group
						array (	
							'type' => 'group',
							'identifier' => 'Title',
							'structuredDataNodes' => array (											
								'structuredDataNode' => array (
								// Short Title
									'type' => 'text',
									'identifier' => 'ShortTitle',
									'text' => $data_descr 
								)
							)
						), // End Title Group
						
						// Description	
						array (
							'type' => 'text',
							'identifier' => 'Description',
							'text' => $data_description
						), // End Description
						
						// Credits Group
						array (
							'type' => 'group',
							'identifier' => 'Credits',
							'structuredDataNodes' => array (
								'structuredDataNode' => array (
									// Minimum Credits
									array (
										'type' => 'text',
										'identifier' => 'CreditMinimumValue',
										'text' => $data_min_units
									),
									
									// Maximum Credits
									array (
										'type' => 'text',
										'identifier' => 'CreditMaximumValue',
										'text' => $data_max_units 
									)
								)
							)
						), // End Credits Group
						
						// Peoplesoft ID Group
						array (
							'type' => 'group',
							'identifier' => 'PeopleSoftIDCodes',
							'structuredDataNodes' => array (
								'structuredDataNode' => array (
									// Course ID
									array (
										'type' => 'text',
										'identifier' => 'CourseID',
										'text' => $data_course_id 	
									),
									
									// CrossListing ID
									array (
										'type' => 'text',
										'identifier' => 'CrosslistingID',
										'text' => $data_crosslisting 
									)
								)
							)
						), // End Peoplesoft ID Group
						
						// School
						array (
							'type' => 'text',
							'identifier' => 'SchoolName',
							'text' => $data_school_name 	
						), // End School						
						
						// Permission
						array (
							'type' => 'text',
							'identifier' => 'PermissionRequired',
							'text' => $data_consent
						), // End Permission
							
						// Grading Option
						array (
							'type' => 'text',
							'identifier' => 'CreditGradingOption',
							'text' => $data_grading
						), // End Grading Option
						
						// Offering Group
						array (
							'type' => 'group',
							'identifier' => 'Offering',
							'structuredDataNodes' => array (
								'structuredDataNode' => array (
									// Currently Offered
									array (
										'type' => 'text',
										'identifier' => 'Status',
										'text' => $data_currently_offered
									),
								)
							)
						), // End Offering Group
						
					) // End StructuredDataNode

				) // End StructuredDataNodes
				
			) // End StructuredData
		)
	);
	
	$params = array( 'authentication' => $auth,
					'asset' => $asset );
	
	try {
		$out = $service->create($params);
		
		if ( $out->createReturn->success != 'true' ) {
			$log .= "Failed to create asset.<br/>";
			$log .= $out->createReturn->message . "<br/><br/>";
		}
		else
		{
			$log .= "Successful creation of asset.<br/><br/>";
		}
	}
	
	catch (Exception $e) {
		$log .= "WSDL creation error on asset:<br/>";
		$log .= $e->getMessage() . "<br/><br/>";
	}

	echo $log;
?>

</body>
</html>
